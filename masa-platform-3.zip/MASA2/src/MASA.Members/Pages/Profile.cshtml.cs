using MASA.Shared.Data;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Members.Pages;
public class MemberProfileModel:BasePage{public MemberProfileModel(MasaDbContext db):base(db){}public void OnGet(){}}
