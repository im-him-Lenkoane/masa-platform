using MASA.Shared.Data;
using MASA.Shared.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Members.Pages.Account;
public class LoginModel : PageModel {
    private readonly MasaDbContext _db;
    public LoginModel(MasaDbContext db)=>_db=db;
    public void OnGet(){}
    public IActionResult OnPost(string Email,string Password){
        var m=_db.Members.FirstOrDefault(u=>u.Email==Email&&u.IsActive);
        if(m==null||!PasswordHelper.Verify(Password,m.PasswordHash)){TempData["Error"]="Invalid email or password.";return Page();}
        HttpContext.Session.SetInt32("MemberId",m.Id);
        HttpContext.Session.SetString("MemberEmail",m.Email);
        return RedirectToPage("/Index");
    }
}
