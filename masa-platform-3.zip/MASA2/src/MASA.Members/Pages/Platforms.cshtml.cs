using MASA.Shared.Data;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Members.Pages;
public class MemberPlatformsModel:BasePage{public MemberPlatformsModel(MasaDbContext db):base(db){}public void OnGet(){}}
