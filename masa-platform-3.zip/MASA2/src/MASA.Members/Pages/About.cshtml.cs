using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Members.Pages;
public class MembersAboutModel : BasePage {
    public MembersAboutModel(MasaDbContext db):base(db){}
    public void OnGet(){}
}
