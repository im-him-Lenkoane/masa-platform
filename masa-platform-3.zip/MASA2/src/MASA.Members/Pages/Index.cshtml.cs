using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Members.Pages;
public class IndexModel : BasePage {
    public bool IsLoggedIn{get;set;}
    public string MemberName{get;set;}="";
    public Member? Member{get;set;}
    public IndexModel(MasaDbContext db):base(db){}
    public void OnGet(){
        var mid=HttpContext.Session.GetInt32("MemberId");
        IsLoggedIn=mid.HasValue;
        if(mid.HasValue){Member=Db.Members.Find(mid.Value);MemberName=Member?.FirstName??"Member";}
    }
}
