using MASA.Shared.Data;
using MASA.Shared.Helpers;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Main.Pages;
public class JoinModel : BasePage {
    private readonly IEmailService _email;
    public JoinModel(MasaDbContext db,IEmailService email):base(db){_email=email;}
    public void OnGet(){}
    public async Task<IActionResult> OnPostAsync(string FirstName,string LastName,string Email,string? Phone,string? SaId){
        if(Db.Members.Any(m=>m.Email==Email)){TempData["Error"]="This email is already registered.";return Page();}
        var member=new Member{
            FirstName=FirstName,LastName=LastName,Email=Email,
            Phone=Phone??string.Empty,SaIdNumber=SaId,
            MembershipNumber=CaseHelper.GenerateMembershipNumber(),
            PasswordHash=PasswordHelper.Hash(Guid.NewGuid().ToString()[..8])
        };
        Db.Members.Add(member);
        await Db.SaveChangesAsync();
        await _email.SendAsync(Email,$"Welcome to MASA, {FirstName}!",$"<h2>Welcome, {FirstName}!</h2><p>Your membership number is: <strong>{member.MembershipNumber}</strong></p><p>A membership administrator will review your application and contact you with platform access details.</p><p>The MASA Team</p>");
        TempData["Success"]=$"Application received! Your membership number is {member.MembershipNumber}. Check your email for confirmation.";
        return RedirectToPage();
    }
}
