using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Main.Pages;
public class ProjectsModel : BasePage {
    public ProjectsModel(MasaDbContext db):base(db){}
    public void OnGet(){}
}
