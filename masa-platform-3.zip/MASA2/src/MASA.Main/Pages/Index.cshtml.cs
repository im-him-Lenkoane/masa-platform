using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Main.Pages;
public class PlatformCard { public string Name{get;set;}="" public string Tag{get;set;}="" public string Desc{get;set;}="" public string Url{get;set;}="" public string IconUrl{get;set;}="" }
public class IndexModel : BasePage {
    public List<PlatformCard> Platforms{get;set;}=new();
    public string HeroBannerUrl{get;set;}="";
    public string AboutImageUrl{get;set;}="";
    public IndexModel(MasaDbContext db):base(db){}
    public void OnGet(){
        HeroBannerUrl=Db.MediaAssets.Where(a=>a.Subdomain=="main"&&a.Tag=="hero_banner")
            .OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
        AboutImageUrl=Db.MediaAssets.Where(a=>a.Subdomain=="main"&&a.Tag=="about_image")
            .OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
        // Load platform icons
        var icons=Db.MediaAssets.Where(a=>a.Category=="icon").ToList();
        string Icon(string tag)=>icons.FirstOrDefault(i=>i.Tag==tag)?.PublicUrl??"";
        Platforms=new List<PlatformCard>{
            new(){Name="Education",Tag="Academic",Url="https://edu.masa.org.za",IconUrl=Icon("icon_edu"),Desc="Grade 10-12 and tertiary support with AI tutoring and live sessions."},
            new(){Name="Builders Academy",Tag="LMS",Url="https://ba.masa.org.za",IconUrl=Icon("icon_ba"),Desc="Full LMS for youth skills development and certification."},
            new(){Name="STEM",Tag="STEM",Url="https://stem.masa.org.za",IconUrl=Icon("icon_stem"),Desc="Out-of-classroom science and technology for South African youth."},
            new(){Name="Morgan in Maths",Tag="Maths",Url="https://minm.masa.org.za",IconUrl=Icon("icon_minm"),Desc="Mathematics for every grade and level by Morgan Itumeleng Lenkoane."},
            new(){Name="Injustices in Society",Tag="Advocacy",Url="https://iis.masa.org.za",IconUrl=Icon("icon_iis"),Desc="Report GBV, service delivery failures, and social injustices."},
            new(){Name="MASA Health",Tag="Health",Url="https://health.masa.org.za",IconUrl=Icon("icon_health"),Desc="SRHR, GBV, chronic and rare disease support and case lodging."},
        };
    }
}
