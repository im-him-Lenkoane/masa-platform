using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Main.Pages;
public class OurStoryModel : BasePage {
    public string StoryContent{get;set;}="";
    public string BannerUrl{get;set;}="";
    public OurStoryModel(MasaDbContext db):base(db){}
    public void OnGet(){
        StoryContent=GetContent("our-story","content","The origin, purpose, and vision of the Messelaar Agency for Social Action — told in full. Content coming soon.");
        BannerUrl=Db.MediaAssets.Where(a=>a.Subdomain=="main"&&a.Tag=="story_banner").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
    }
}
