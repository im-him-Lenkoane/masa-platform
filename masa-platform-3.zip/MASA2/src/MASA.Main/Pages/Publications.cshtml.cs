using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Main.Pages;
public class PublicationsModel : BasePage {
    public List<Publication> Publications{get;set;}=new();
    public PublicationsModel(MasaDbContext db):base(db){}
    public void OnGet(){
        Publications=Db.Publications.Include(p=>p.Document).Where(p=>p.Subdomain=="main"&&p.IsPublished).OrderByDescending(p=>p.PublishedAt).ToList();
    }
}
