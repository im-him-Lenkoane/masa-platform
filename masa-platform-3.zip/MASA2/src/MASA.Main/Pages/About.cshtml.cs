using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Main.Pages;
public class AboutModel : BasePage {
    public string AboutBody{get;set;}="";
    public string Mission{get;set;}="";
    public string Vision{get;set;}="";
    public string BannerUrl{get;set;}="";
    public AboutModel(MasaDbContext db):base(db){}
    public void OnGet(){
        AboutBody=GetContent("about","about_body","");
        Mission=GetContent("about","mission_statement","");
        Vision=GetContent("about","vision_statement","");
        BannerUrl=Db.MediaAssets.Where(a=>a.Subdomain=="main"&&a.Tag=="about_banner").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
    }
}
