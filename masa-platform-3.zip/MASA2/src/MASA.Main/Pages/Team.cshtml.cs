using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Main.Pages;
public class TeamModel : BasePage {
    public List<TeamMember> Team{get;set;}=new();
    public TeamModel(MasaDbContext db):base(db){}
    public void OnGet(){
        Team=Db.TeamMembers.Include(t=>t.Photo).Where(t=>t.Subdomain=="main"&&t.IsActive).OrderBy(t=>t.SortOrder).ToList();
    }
}
