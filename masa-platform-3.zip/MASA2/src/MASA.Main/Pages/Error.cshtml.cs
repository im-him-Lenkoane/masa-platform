using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Main.Pages;
[ResponseCache(Duration=0,Location=ResponseCacheLocation.None,NoStore=true)]
[IgnoreAntiforgeryToken]
public class ErrorModel : PageModel {
    public int StatusCode { get; set; }=500;
    public string Title { get; set; }="Something went wrong";
    public string Message { get; set; }="An unexpected error occurred.";
    public void OnGet(int? code) {
        StatusCode=code??500;
        Title=StatusCode switch{404=>"Page Not Found",403=>"Access Denied",_=>"Something Went Wrong"};
        Message=StatusCode switch{404=>"The page you are looking for doesn't exist.",403=>"You don't have permission to view this page.",_=>"An unexpected error occurred. Please try again."};
    }
}
