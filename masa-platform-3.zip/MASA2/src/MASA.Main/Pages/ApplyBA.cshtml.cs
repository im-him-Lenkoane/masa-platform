using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Main.Pages;
public class ApplyBAModel : BasePage {
    private readonly IEmailService _email;
    public ApplyBAModel(MasaDbContext db,IEmailService email):base(db){_email=email;}
    public void OnGet(){}
    public async Task<IActionResult> OnPostAsync(string FirstName,string LastName,string Email,string Phone,string Motivation,string? Interest){
        // Store as a member application note
        var member=Db.Members.FirstOrDefault(m=>m.Email==Email);
        if(member==null){
            member=new Member{FirstName=FirstName,LastName=LastName,Email=Email,Phone=Phone,
                MembershipNumber=MASA.Shared.Helpers.CaseHelper.GenerateMembershipNumber(),
                PasswordHash=MASA.Shared.Helpers.PasswordHelper.Hash(Guid.NewGuid().ToString()[..8]),
                Notes=$"BA Application - Interest: {Interest}. Motivation: {Motivation}"};
            Db.Members.Add(member);
        }else{
            member.Notes+=$"\nBA Application - Interest: {Interest}. Motivation: {Motivation}";
        }
        await Db.SaveChangesAsync();
        await _email.SendAsync(Email,$"Builders Academy Application Received",$"<h2>Hi {FirstName},</h2><p>Your Builders Academy application has been received. We will review it and contact you shortly.</p><p>The MASA Team</p>");
        TempData["Success"]="Application submitted successfully! We will be in touch.";
        return RedirectToPage();
    }
}
