using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.MINM.Pages;
public class MINMAboutModel : BasePage {
    public string AboutText{get;set;}="";
    public string PhilosophyText{get;set;}="";
    public string PhotoUrl{get;set;}="";
    public List<TeamMember> Tutors{get;set;}=new();
    public MINMAboutModel(MasaDbContext db):base(db){}
    public void OnGet(){
        AboutText=GetContent("minm","about","Morgan Itumeleng Lenkoane is the Founder and Co-Establisher of MASA NPC, and the creator of Morgan in Maths — a platform dedicated to making mathematics accessible to every South African at every level.");
        PhilosophyText=GetContent("minm","philosophy","From Grade 1 counting to university calculus, Morgan believes that every learner can excel in mathematics with the right guidance, patience, and resources.");
        PhotoUrl=Db.MediaAssets.Where(a=>a.Tag=="morgan_photo").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
        Tutors=Db.TeamMembers.Include(t=>t.Photo).Where(t=>t.Subdomain=="minm"&&t.IsActive).OrderBy(t=>t.SortOrder).ToList();
    }
}
