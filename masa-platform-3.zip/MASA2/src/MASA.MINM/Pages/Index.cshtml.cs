using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.MINM.Pages;
public class IndexModel : BasePage {
    public List<EduGrade> Grades{get;set;}=new();
    public List<EduFaculty> Faculties{get;set;}=new();
    public string MorganPhotoUrl{get;set;}="";
    public IndexModel(MasaDbContext db):base(db){}
    public void OnGet(){
        Grades=Db.EduGrades.Where(g=>g.Subdomain=="minm"&&g.Level=="school"&&g.IsActive).OrderBy(g=>g.SortOrder).ToList();
        Faculties=Db.EduFaculties.Where(f=>f.Subdomain=="minm"&&f.IsActive).OrderBy(f=>f.SortOrder).ToList();
        MorganPhotoUrl=Db.MediaAssets.Where(a=>a.Tag=="morgan_photo").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
    }
}
