using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc.RazorPages;using Microsoft.EntityFrameworkCore;
namespace MASA.MINM.Pages;
public class MINMSchoolModel:BasePage{public List<EduGrade> Grades{get;set;}=new();
public MINMSchoolModel(MasaDbContext db):base(db){}
public void OnGet(){Grades=Db.EduGrades.Include(g=>g.Subjects).Where(g=>g.Subdomain=="minm"&&g.Level=="school"&&g.IsActive).OrderBy(g=>g.SortOrder).ToList();}}
