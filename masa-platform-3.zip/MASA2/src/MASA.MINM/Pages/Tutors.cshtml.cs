using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc.RazorPages;using Microsoft.EntityFrameworkCore;
namespace MASA.MINM.Pages;
public class MINMTutorsModel:BasePage{public List<TeamMember> Tutors{get;set;}=new();
public MINMTutorsModel(MasaDbContext db):base(db){}
public void OnGet(){Tutors=Db.TeamMembers.Include(t=>t.Photo).Where(t=>t.Subdomain=="minm"&&t.IsActive).OrderBy(t=>t.SortOrder).ToList();}}
