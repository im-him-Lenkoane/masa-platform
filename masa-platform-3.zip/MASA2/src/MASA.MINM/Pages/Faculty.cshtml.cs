using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc.RazorPages;using Microsoft.EntityFrameworkCore;
namespace MASA.MINM.Pages;
public class MINMFacultyModel:BasePage{public EduFaculty? Faculty{get;set;}public List<EduSubject> Subjects{get;set;}=new();
public MINMFacultyModel(MasaDbContext db):base(db){}
public void OnGet(int facultyId){Faculty=Db.EduFaculties.Find(facultyId);Subjects=Db.EduSubjects.Include(s=>s.Banner).Include(s=>s.Topics).Where(s=>s.FacultyId==facultyId&&s.IsPublished&&s.Subdomain=="minm").OrderBy(s=>s.SortOrder).ToList();}}
