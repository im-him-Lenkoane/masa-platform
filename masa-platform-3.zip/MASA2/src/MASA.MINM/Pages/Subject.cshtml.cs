using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.MINM.Pages;
public class MINMSubjectPage : BasePage {
    public EduSubject? Subject{get;set;}
    public List<EduTopic> Topics{get;set;}=new();
    public MINMSubjectPage(MasaDbContext db):base(db){}
    public IActionResult OnGet(int subjectId){
        Subject=Db.EduSubjects.Include(s=>s.Banner).FirstOrDefault(s=>s.Id==subjectId&&s.IsPublished);
        if(Subject==null)return RedirectToPage("/Index");
        Topics=Db.EduTopics.Include(t=>t.Contents).ThenInclude(c=>c.Asset).Where(t=>t.SubjectId==subjectId).OrderBy(t=>t.SortOrder).ToList();
        return Page();
    }
}
