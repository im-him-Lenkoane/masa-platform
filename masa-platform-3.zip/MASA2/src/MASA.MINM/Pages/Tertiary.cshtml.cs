using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc.RazorPages;using Microsoft.EntityFrameworkCore;
namespace MASA.MINM.Pages;
public class MINMTertiaryModel:BasePage{public List<EduFaculty> Faculties{get;set;}=new();
public MINMTertiaryModel(MasaDbContext db):base(db){}
public void OnGet(){Faculties=Db.EduFaculties.Include(f=>f.Subjects).Where(f=>f.Subdomain=="minm"&&f.IsActive).OrderBy(f=>f.SortOrder).ToList();}}
