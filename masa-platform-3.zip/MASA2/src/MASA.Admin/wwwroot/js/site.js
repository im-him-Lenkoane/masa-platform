// MASA Platform — masa.js
(function(){
  var t=localStorage.getItem('masa-theme')||'light';
  document.documentElement.setAttribute('data-theme',t);
})();
function toggleTheme(){
  var h=document.documentElement,n=h.getAttribute('data-theme')==='dark'?'light':'dark';
  h.setAttribute('data-theme',n);localStorage.setItem('masa-theme',n);
  var b=document.getElementById('themeBtn');if(b)b.textContent=n==='dark'?'Sun':'Moon';
}
function toggleMenu(){var m=document.getElementById('navMobile');if(m)m.classList.toggle('open');}
function toggleAccordion(header){
  header.classList.toggle('open');
  var body=header.nextElementSibling;if(body)body.classList.toggle('open');
}
function toggleChat(){var p=document.getElementById('chatPanel');if(p)p.classList.toggle('open');}
async function sendChat(){
  var inp=document.getElementById('chatInput'),msgs=document.getElementById('chatMessages');
  var subject=document.getElementById('chatSubject')?.value||'';
  var topic=document.getElementById('chatTopic')?.value||'';
  if(!inp||!inp.value.trim())return;
  var q=inp.value.trim();inp.value='';
  appendMsg(msgs,q,'user');
  var thinkEl=appendMsg(msgs,'Thinking...','ai');
  try{
    var res=await fetch('/api/tutor',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({question:q,subject:subject,topic:topic,level:'intermediate'})});
    var data=await res.json();
    thinkEl.textContent=data.answer||data.error||'Sorry, I am unavailable.';
  }catch{thinkEl.textContent='Sorry, I am temporarily unavailable.';}
  msgs.scrollTop=msgs.scrollHeight;
}
function appendMsg(container,text,type){
  var d=document.createElement('div');d.className='chat-msg '+type;d.textContent=text;
  container.appendChild(d);container.scrollTop=container.scrollHeight;return d;
}
document.addEventListener('DOMContentLoaded',function(){
  var b=document.getElementById('themeBtn');
  if(b){b.textContent=document.documentElement.getAttribute('data-theme')==='dark'?'Sun':'Moon';}
  if('IntersectionObserver' in window){
    var obs=new IntersectionObserver(function(e){
      e.forEach(function(x){if(x.isIntersecting){x.target.style.animationPlayState='running';obs.unobserve(x.target);}});
    },{threshold:0.12});
    document.querySelectorAll('.anim').forEach(function(el){el.style.animationPlayState='paused';obs.observe(el);});
  }
  var ci=document.getElementById('chatInput');
  if(ci)ci.addEventListener('keypress',function(e){if(e.key==='Enter')sendChat();});
});
