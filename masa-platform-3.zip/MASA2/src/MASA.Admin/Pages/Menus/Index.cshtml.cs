using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Menus;
public class MenusIndexModel : PageModel {
    private readonly MasaDbContext _db;
    public List<SiteMenu> Menus{get;set;}=new();
    public string SubFilter{get;set;}="main";
    public MenusIndexModel(MasaDbContext db)=>_db=db;
    public void OnGet(string? sub){SubFilter=sub??"main";Menus=_db.SiteMenus.Where(m=>m.Subdomain==SubFilter).OrderBy(m=>m.SortOrder).ToList();}
    public IActionResult OnPostAdd(string Subdomain,string Label,string Url,int SortOrder){
        _db.SiteMenus.Add(new SiteMenu{Subdomain=Subdomain,Label=Label,Url=Url,SortOrder=SortOrder});
        _db.SaveChanges();TempData["Success"]="Menu item added.";return RedirectToPage(new{sub=Subdomain});
    }
    public IActionResult OnPostToggle(int Id){
        var m=_db.SiteMenus.Find(Id);if(m!=null){m.IsActive=!m.IsActive;_db.SaveChanges();}
        return RedirectToPage(new{sub=_db.SiteMenus.Find(Id)?.Subdomain??"main"});
    }
    public IActionResult OnPostDelete(int Id){
        var m=_db.SiteMenus.Find(Id);if(m!=null){_db.SiteMenus.Remove(m);_db.SaveChanges();}
        TempData["Success"]="Menu item deleted.";return RedirectToPage();
    }
}
