using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Members;
public class MemberEditModel : PageModel {
    private readonly MasaDbContext _db;
    public Member? Member{get;set;}
    public MemberEditModel(MasaDbContext db)=>_db=db;
    public void OnGet(int id){Member=_db.Members.Find(id);}
    public IActionResult OnPost(int MemberId,string FirstName,string LastName,string Email,string? Phone,string? Notes,bool HasEduAccess,bool HasBaAccess,bool HasMinmAccess,bool IsActive){
        var m=_db.Members.Find(MemberId);
        if(m==null){TempData["Error"]="Member not found.";return RedirectToPage("/Members/Index");}
        m.FirstName=FirstName;m.LastName=LastName;m.Email=Email;m.Phone=Phone??"";
        m.Notes=Notes??"";m.HasEduAccess=HasEduAccess;m.HasBaAccess=HasBaAccess;
        m.HasMinmAccess=HasMinmAccess;m.IsActive=IsActive;
        _db.SaveChanges();
        TempData["Success"]="Member updated.";return RedirectToPage("/Members/Index");
    }
}
