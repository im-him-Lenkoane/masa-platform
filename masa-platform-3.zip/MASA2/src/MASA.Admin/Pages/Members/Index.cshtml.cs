using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Members;
public class MembersIndexModel : PageModel {
    private readonly MasaDbContext _db;
    public List<Member> Members{get;set;}=new();
    public string? Search{get;set;}
    public MembersIndexModel(MasaDbContext db)=>_db=db;
    public void OnGet(string? search){
        Search=search;
        var q=_db.Members.AsQueryable();
        if(!string.IsNullOrEmpty(search)) q=q.Where(m=>m.Email.Contains(search)||m.FirstName.Contains(search)||m.LastName.Contains(search)||m.MembershipNumber.Contains(search));
        Members=q.OrderByDescending(m=>m.JoinedAt).ToList();
    }
}
