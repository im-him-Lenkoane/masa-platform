using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.Users;
public class UsersIndexModel : PageModel {
    private readonly MasaDbContext _db;
    public List<AdminUser> Users{get;set;}=new();
    public UsersIndexModel(MasaDbContext db)=>_db=db;
    public void OnGet(){Users=_db.AdminUsers.Include(u=>u.Role).OrderBy(u=>u.FirstName).ToList();}
}
