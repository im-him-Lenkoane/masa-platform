using MASA.Shared.Data;
using MASA.Shared.Helpers;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Users;
public class UserCreateModel : PageModel {
    private readonly MasaDbContext _db;private readonly IEmailService _email;
    public List<Role> Roles{get;set;}=new();
    public UserCreateModel(MasaDbContext db,IEmailService email){_db=db;_email=email;}
    public void OnGet(){Roles=_db.Roles.OrderBy(r=>r.Name).ToList();}
    public async Task<IActionResult> OnPostAsync(string FirstName,string LastName,string Email,string Password,int RoleId,string Subdomain){
        if(_db.AdminUsers.Any(u=>u.Email==Email)){TempData["Error"]="Email already exists.";Roles=_db.Roles.ToList();return Page();}
        _db.AdminUsers.Add(new AdminUser{FirstName=FirstName,LastName=LastName,Email=Email,PasswordHash=PasswordHelper.Hash(Password),RoleId=RoleId,Subdomain=Subdomain});
        await _db.SaveChangesAsync();
        await _email.SendCredentialsAsync(Email,$"{FirstName} {LastName}",Email,Password,"MASA Admin");
        TempData["Success"]="Admin user created and credentials sent.";
        return RedirectToPage("/Users/Index");
    }
}
