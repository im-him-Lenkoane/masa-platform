using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.Health;
public class HealthCasesModel : PageModel {
    private readonly MasaDbContext _db;
    public List<CaseSubmission> Cases{get;set;}=new();
    public string StatusFilter{get;set;}="all";
    public HealthCasesModel(MasaDbContext db)=>_db=db;
    public void OnGet(string? status){
        StatusFilter=status??"all";
        var q=_db.CaseSubmissions.Include(c=>c.CaseType).Where(c=>c.Subdomain=="health");
        if(StatusFilter!="all") q=q.Where(c=>c.Status==StatusFilter);
        Cases=q.OrderByDescending(c=>c.SubmittedAt).ToList();
    }
}
