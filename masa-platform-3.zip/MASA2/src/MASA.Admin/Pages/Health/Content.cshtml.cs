using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Health;
public class HealthContentPageModel:PageModel{private readonly MasaDbContext _db;public List<HealthContent> Contents{get;set;}=new();
public HealthContentPageModel(MasaDbContext db)=>_db=db;
public void OnGet(){Contents=_db.HealthContents.OrderBy(c=>c.Category).ThenBy(c=>c.SortOrder).ToList();}
public IActionResult OnPostToggle(int Id){var c=_db.HealthContents.Find(Id);if(c!=null){c.IsPublished=!c.IsPublished;_db.SaveChanges();}return RedirectToPage();}}
