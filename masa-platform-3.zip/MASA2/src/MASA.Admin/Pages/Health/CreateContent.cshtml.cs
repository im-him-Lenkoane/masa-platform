using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Health;
public class CreateHealthContentModel:PageModel{private readonly MasaDbContext _db;
public CreateHealthContentModel(MasaDbContext db)=>_db=db;public void OnGet(){}
public IActionResult OnPost(string Title,string Category,string? Body,string? VideoUrl,string? BannerUrl,bool RequiresAgeGate,bool IsPublished){
    int? banId=null;if(!string.IsNullOrEmpty(BannerUrl)){var a=_db.MediaAssets.FirstOrDefault(x=>x.PublicUrl==BannerUrl);banId=a?.Id;}
    _db.HealthContents.Add(new HealthContent{Title=Title,Category=Category,Body=Body??"",VideoUrl=VideoUrl??"",BannerAssetId=banId,RequiresAgeGate=RequiresAgeGate,IsPublished=IsPublished});
    _db.SaveChanges();TempData["Success"]="Content saved.";return RedirectToPage("/Health/Content");}}
