using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Health;
public class HealthContentAdminModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public List<HealthContent> Contents{get;set;}=new();
    public HealthContentAdminModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(){Contents=_db.HealthContents.OrderBy(c=>c.Category).ThenBy(c=>c.SortOrder).ToList();}
    public async Task<IActionResult> OnPostAddAsync(string Title,string Category,string? Body,string? VideoUrl,IFormFile? BannerFile,bool RequiresAgeGate,bool IsPublished){
        int? bannerId=null;
        if(BannerFile!=null&&BannerFile.Length>0){
            using var s=BannerFile.OpenReadStream();
            var(k,u)=await _media.UploadAsync(s,BannerFile.FileName,"health","banner",BannerFile.ContentType);
            bannerId=_db.MediaAssets.First(a=>a.S3Key==k).Id;
        }
        _db.HealthContents.Add(new HealthContent{Title=Title,Category=Category,Body=Body??"",VideoUrl=VideoUrl??"",BannerAssetId=bannerId,RequiresAgeGate=RequiresAgeGate,IsPublished=IsPublished});
        await _db.SaveChangesAsync();TempData["Success"]="Content added.";return RedirectToPage();
    }
    public IActionResult OnPostDelete(int Id){var c=_db.HealthContents.Find(Id);if(c!=null){_db.HealthContents.Remove(c);_db.SaveChanges();}return RedirectToPage();}
}
