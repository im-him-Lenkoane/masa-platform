using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.Edu;
public class EduTopicsModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public EduSubject? Subject{get;set;}
    public List<EduTopic> Topics{get;set;}=new();
    public int SubjectId{get;set;}
    public EduTopicsModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(int subjectId){
        SubjectId=subjectId;
        Subject=_db.EduSubjects.Include(s=>s.Banner).FirstOrDefault(s=>s.Id==subjectId);
        Topics=_db.EduTopics.Include(t=>t.Contents).ThenInclude(c=>c.Asset)
            .Where(t=>t.SubjectId==subjectId).OrderBy(t=>t.SortOrder).ToList();
    }
    public IActionResult OnPostAddTopic(int SubjectId,string Title,int SortOrder){
        _db.EduTopics.Add(new EduTopic{SubjectId=SubjectId,Title=Title,SortOrder=SortOrder});
        _db.SaveChanges();TempData["Success"]="Topic added.";return RedirectToPage(new{subjectId=SubjectId});
    }
    public IActionResult OnPostDeleteTopic(int TopicId){
        var t=_db.EduTopics.Include(x=>x.Contents).FirstOrDefault(x=>x.Id==TopicId);
        if(t!=null){_db.EduTopics.Remove(t);_db.SaveChanges();}
        TempData["Success"]="Topic deleted.";return RedirectToPage(new{subjectId=t?.SubjectId??0});
    }
    public async Task<IActionResult> OnPostAddContentAsync(int TopicId,string Title,string ContentType,IFormFile? ContentFile,string? ExternalUrl){
        var topic=_db.EduTopics.Find(TopicId);
        if(topic==null)return RedirectToPage();
        var subj=_db.EduSubjects.Find(topic.SubjectId);
        int? assetId=null;
        if(ContentFile!=null&&ContentFile.Length>0){
            using var s=ContentFile.OpenReadStream();
            var(k,u)=await _media.UploadAsync(s,ContentFile.FileName,subj?.Subdomain??"edu","content",ContentFile.ContentType);
            assetId=_db.MediaAssets.First(a=>a.S3Key==k).Id;
        }
        _db.EduContents.Add(new EduContent{TopicId=TopicId,Title=Title,ContentType=ContentType,
            MediaAssetId=assetId,ExternalUrl=ExternalUrl??"",IsPublished=true});
        await _db.SaveChangesAsync();
        TempData["Success"]="Content added.";return RedirectToPage(new{subjectId=topic.SubjectId});
    }
    public IActionResult OnPostDeleteContent(int ContentId){
        var c=_db.EduContents.Find(ContentId);
        if(c!=null){_db.EduContents.Remove(c);_db.SaveChanges();}
        return RedirectToPage(new{subjectId=_db.EduTopics.Find(c?.TopicId??0)?.SubjectId??0});
    }
    public async Task<IActionResult> OnPostUpdateBannerAsync(int SubjectId,IFormFile? BannerFile){
        if(BannerFile!=null&&BannerFile.Length>0){
            using var s=BannerFile.OpenReadStream();
            var subj=_db.EduSubjects.Find(SubjectId);
            var(k,u)=await _media.UploadAsync(s,BannerFile.FileName,subj?.Subdomain??"edu","banner",BannerFile.ContentType);
            var assetId=_db.MediaAssets.First(a=>a.S3Key==k).Id;
            if(subj!=null){subj.BannerAssetId=assetId;await _db.SaveChangesAsync();}
        }
        return RedirectToPage(new{subjectId=SubjectId});
    }
}
