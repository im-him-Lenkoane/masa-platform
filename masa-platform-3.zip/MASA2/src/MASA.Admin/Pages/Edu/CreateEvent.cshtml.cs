using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Edu;
public class CreateEventModel:PageModel{private readonly MasaDbContext _db;
public CreateEventModel(MasaDbContext db)=>_db=db;public void OnGet(){}
public IActionResult OnPost(string Title,string? Description,string Subdomain,DateTime EventDate,string? Location,string? StreamUrl,bool IsPublished){
    _db.EduEvents.Add(new EduEvent{Title=Title,Description=Description??"",Subdomain=Subdomain,EventDate=EventDate,Location=Location??"",StreamUrl=StreamUrl??"",IsPublished=IsPublished});
    _db.SaveChanges();TempData["Success"]="Event saved.";return RedirectToPage("/Edu/Events");}}
