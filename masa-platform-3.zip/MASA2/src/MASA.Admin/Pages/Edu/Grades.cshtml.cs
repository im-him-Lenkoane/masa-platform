using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Edu;
public class EduGradesModel:PageModel{private readonly MasaDbContext _db;
public List<EduGrade> Grades{get;set;}=new();public List<EduFaculty> Faculties{get;set;}=new();
public EduGradesModel(MasaDbContext db)=>_db=db;
public void OnGet(){Grades=_db.EduGrades.OrderBy(g=>g.Subdomain).ThenBy(g=>g.SortOrder).ToList();Faculties=_db.EduFaculties.OrderBy(f=>f.Subdomain).ThenBy(f=>f.SortOrder).ToList();}
public IActionResult OnPostAddGrade(string GradeName,string GradeSub){_db.EduGrades.Add(new EduGrade{Name=GradeName,Subdomain=GradeSub,Level="school",SortOrder=99});_db.SaveChanges();return RedirectToPage();}
public IActionResult OnPostDeleteGrade(int Id){var g=_db.EduGrades.Find(Id);if(g!=null){_db.EduGrades.Remove(g);_db.SaveChanges();}return RedirectToPage();}
public IActionResult OnPostAddFaculty(string FacName,string FacSub){_db.EduFaculties.Add(new EduFaculty{Name=FacName,Subdomain=FacSub,SortOrder=99});_db.SaveChanges();return RedirectToPage();}
public IActionResult OnPostDeleteFaculty(int Id){var f=_db.EduFaculties.Find(Id);if(f!=null){_db.EduFaculties.Remove(f);_db.SaveChanges();}return RedirectToPage();}}
