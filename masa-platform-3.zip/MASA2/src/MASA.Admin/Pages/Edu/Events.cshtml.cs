using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Edu;
public class EduEventsModel:PageModel{private readonly MasaDbContext _db;public List<EduEvent> Events{get;set;}=new();
public EduEventsModel(MasaDbContext db)=>_db=db;
public void OnGet(){Events=_db.EduEvents.OrderByDescending(e=>e.EventDate).ToList();}
public IActionResult OnPostToggle(int Id){var e=_db.EduEvents.Find(Id);if(e!=null){e.IsPublished=!e.IsPublished;_db.SaveChanges();}return RedirectToPage();}}
