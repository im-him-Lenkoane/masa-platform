using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Edu;
public class CreateSubjectModel:PageModel{private readonly MasaDbContext _db;
public List<EduGrade> Grades{get;set;}=new();public List<EduFaculty> Faculties{get;set;}=new();
public CreateSubjectModel(MasaDbContext db)=>_db=db;
public void OnGet(){Grades=_db.EduGrades.Where(g=>g.IsActive).OrderBy(g=>g.Subdomain).ThenBy(g=>g.SortOrder).ToList();
    Faculties=_db.EduFaculties.Where(f=>f.IsActive).OrderBy(f=>f.Subdomain).ThenBy(f=>f.SortOrder).ToList();}
public IActionResult OnPost(string Name,string? Description,string Subdomain,string Level,int? GradeId,int? FacultyId,string? BannerUrl,bool IsPublished){
    int? banId=null;if(!string.IsNullOrEmpty(BannerUrl)){var a=_db.MediaAssets.FirstOrDefault(x=>x.PublicUrl==BannerUrl);banId=a?.Id;}
    _db.EduSubjects.Add(new EduSubject{Name=Name,Description=Description??"",Subdomain=Subdomain,Level=Level,GradeId=GradeId==0?null:GradeId,FacultyId=FacultyId==0?null:FacultyId,BannerAssetId=banId,IsPublished=IsPublished});
    _db.SaveChanges();TempData["Success"]="Subject created.";return RedirectToPage("/Edu/Subjects");}}
