using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.Edu;
public class EduSubjectsModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public List<EduSubject> Subjects{get;set;}=new();
    public List<EduGrade> Grades{get;set;}=new();
    public List<EduFaculty> Faculties{get;set;}=new();
    public string SubFilter{get;set;}="edu";
    public EduSubjectsModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(string? sub){
        SubFilter=sub??"edu";
        Subjects=_db.EduSubjects.Include(s=>s.Topics).Include(s=>s.Grade).Include(s=>s.Faculty)
            .Include(s=>s.Banner).Where(s=>s.Subdomain==SubFilter).OrderBy(s=>s.SortOrder).ToList();
        Grades=_db.EduGrades.OrderBy(g=>g.Subdomain).ThenBy(g=>g.SortOrder).ToList();
        Faculties=_db.EduFaculties.OrderBy(f=>f.Subdomain).ThenBy(f=>f.SortOrder).ToList();
    }
    public async Task<IActionResult> OnPostAddAsync(string Name,string Subdomain,string Level,int? GradeId,int? FacultyId,string? Description,IFormFile? BannerFile,string IsPublished){
        int? bannerId=null;
        if(BannerFile!=null&&BannerFile.Length>0){
            using var s=BannerFile.OpenReadStream();
            var(k,u)=await _media.UploadAsync(s,BannerFile.FileName,Subdomain,"banner",BannerFile.ContentType);
            bannerId=_db.MediaAssets.First(a=>a.S3Key==k).Id;
        }
        _db.EduSubjects.Add(new EduSubject{Name=Name,Subdomain=Subdomain,Level=Level,
            GradeId=GradeId==0?null:GradeId,FacultyId=FacultyId==0?null:FacultyId,
            Description=Description??"",BannerAssetId=bannerId,IsPublished=IsPublished=="true"});
        await _db.SaveChangesAsync();
        TempData["Success"]="Subject added.";return RedirectToPage(new{sub=Subdomain});
    }
    public async Task<IActionResult> OnPostDeleteAsync(int Id){
        var s=_db.EduSubjects.Include(x=>x.Topics).ThenInclude(t=>t.Contents).First(x=>x.Id==Id);
        _db.EduSubjects.Remove(s);await _db.SaveChangesAsync();
        TempData["Success"]="Subject deleted.";return RedirectToPage();
    }
}
