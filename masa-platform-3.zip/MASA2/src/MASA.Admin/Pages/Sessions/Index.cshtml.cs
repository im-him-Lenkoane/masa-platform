using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Sessions;
public class SessionsAdminModel : PageModel {
    private readonly MasaDbContext _db;
    public List<LiveSession> Sessions{get;set;}=new();
    public SessionsAdminModel(MasaDbContext db)=>_db=db;
    public void OnGet(){Sessions=_db.LiveSessions.OrderByDescending(s=>s.SessionDate).Take(50).ToList();}
    public IActionResult OnPostAdd(string Title,string Subdomain,string? Description,DateTime SessionDate,string StreamType,string? StreamUrl){
        _db.LiveSessions.Add(new LiveSession{Title=Title,Subdomain=Subdomain,Description=Description??"",SessionDate=SessionDate,StreamType=StreamType,StreamUrl=StreamUrl??"",IsPublished=true});
        _db.SaveChanges();TempData["Success"]="Session scheduled.";return RedirectToPage();
    }
    public IActionResult OnPostToggleLive(int Id){var s=_db.LiveSessions.Find(Id);if(s!=null){s.IsLive=!s.IsLive;_db.SaveChanges();}return RedirectToPage();}
    public IActionResult OnPostDelete(int Id){var s=_db.LiveSessions.Find(Id);if(s!=null){_db.LiveSessions.Remove(s);_db.SaveChanges();}return RedirectToPage();}
}
