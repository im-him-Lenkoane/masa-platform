using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Sessions;
public class SessionCreateModel:PageModel{private readonly MasaDbContext _db;
public SessionCreateModel(MasaDbContext db)=>_db=db;public void OnGet(){}
public IActionResult OnPost(string Title,string? Description,string Subdomain,string StreamType,DateTime SessionDate,string StreamUrl,bool IsPublished){
    _db.LiveSessions.Add(new LiveSession{Title=Title,Description=Description??"",Subdomain=Subdomain,StreamType=StreamType,SessionDate=SessionDate,StreamUrl=StreamUrl,IsPublished=IsPublished});
    _db.SaveChanges();TempData["Success"]="Session scheduled.";return RedirectToPage("/Sessions/Index");}}
