using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Media;
public class MediaIndexModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public List<MediaAsset> Assets{get;set;}=new();
    public string? Filter{get;set;}
    public MediaIndexModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(string? filter){
        Filter=filter;
        var q=_db.MediaAssets.AsQueryable();
        if(!string.IsNullOrEmpty(filter)&&filter!="all") q=q.Where(a=>a.Subdomain==filter);
        Assets=q.OrderByDescending(a=>a.UploadedAt).Take(300).ToList();
    }
    public async Task<IActionResult> OnPostUploadAsync(IFormFile File,string Subdomain,string? Tag){
        if(File==null||File.Length==0){TempData["Error"]="No file selected.";return RedirectToPage();}
        if(!_media.IsAllowedType(File.ContentType)){TempData["Error"]=$"File type {File.ContentType} not allowed.";return RedirectToPage();}
        if(File.Length>50*1024*1024){TempData["Error"]="Max file size is 50MB.";return RedirectToPage();}
        using var s=File.OpenReadStream();
        var(key,url)=await _media.UploadAsync(s,File.FileName,Subdomain,"media",File.ContentType);
        if(!string.IsNullOrEmpty(Tag)){
            var asset=_db.MediaAssets.FirstOrDefault(a=>a.S3Key==key);
            if(asset!=null){
                asset.Tag=Tag;
                asset.Category=Tag.Contains("banner")?"banner":Tag.Contains("icon")?"icon":Tag.Contains("logo")?"logo":File.ContentType=="image/gif"?"gif":"image";
                await _db.SaveChangesAsync();
            }
        }
        TempData["Success"]=$"Uploaded: {File.FileName}";
        return RedirectToPage();
    }
    public async Task<IActionResult> OnPostDeleteAsync(int AssetId){
        var a=_db.MediaAssets.Find(AssetId);
        if(a!=null)await _media.DeleteAsync(a.S3Key);
        TempData["Success"]="Asset deleted.";
        return RedirectToPage();
    }
}
