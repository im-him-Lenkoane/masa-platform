using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.Team;
public class TeamAdminModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public List<TeamMember> Members{get;set;}=new();
    public TeamAdminModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(){Members=_db.TeamMembers.Include(m=>m.Photo).OrderBy(m=>m.Subdomain).ThenBy(m=>m.SortOrder).ToList();}
    public async Task<IActionResult> OnPostAddAsync(string Name,string Role,string? Bio,IFormFile? PhotoFile,string Subdomain,int SortOrder){
        int? photoId=null;
        if(PhotoFile!=null&&PhotoFile.Length>0){
            using var s=PhotoFile.OpenReadStream();
            var(k,u)=await _media.UploadAsync(s,PhotoFile.FileName,Subdomain,"image",PhotoFile.ContentType);
            photoId=_db.MediaAssets.First(a=>a.S3Key==k).Id;
        }
        _db.TeamMembers.Add(new TeamMember{Name=Name,Role=Role,Bio=Bio??"",PhotoAssetId=photoId,Subdomain=Subdomain,SortOrder=SortOrder});
        await _db.SaveChangesAsync();TempData["Success"]="Team member added.";return RedirectToPage();
    }
    public IActionResult OnPostDelete(int Id){var m=_db.TeamMembers.Find(Id);if(m!=null){_db.TeamMembers.Remove(m);_db.SaveChanges();}return RedirectToPage();}
}
