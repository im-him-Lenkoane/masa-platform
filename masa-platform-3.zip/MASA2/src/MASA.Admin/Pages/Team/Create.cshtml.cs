using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Team;
public class TeamCreateModel:PageModel{private readonly MasaDbContext _db;
public TeamCreateModel(MasaDbContext db)=>_db=db;
public void OnGet(){}
public IActionResult OnPost(string Name,string Role,string? Bio,string Subdomain,string? PhotoUrl,int SortOrder){
    int? photoId=null;
    if(!string.IsNullOrEmpty(PhotoUrl)){var a=_db.MediaAssets.FirstOrDefault(x=>x.PublicUrl==PhotoUrl);photoId=a?.Id;}
    _db.TeamMembers.Add(new TeamMember{Name=Name,Role=Role,Bio=Bio??"",Subdomain=Subdomain,PhotoAssetId=photoId,SortOrder=SortOrder});
    _db.SaveChanges();TempData["Success"]="Team member added.";return RedirectToPage("/Team/Index");}}
