using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Content;
public class ContentIndexModel : PageModel {
    private readonly MasaDbContext _db;
    public List<SiteContent> Contents{get;set;}=new();
    public string SubFilter{get;set;}="main";
    public ContentIndexModel(MasaDbContext db)=>_db=db;
    public void OnGet(string? sub){
        SubFilter=sub??"main";
        Contents=_db.SiteContents.Where(c=>c.Subdomain==SubFilter).OrderBy(c=>c.Page).ThenBy(c=>c.ElementKey).ToList();
    }
    public IActionResult OnPost(string Subdomain,List<int> Keys,List<string> Values){
        for(int i=0;i<Keys.Count&&i<Values.Count;i++){
            var item=_db.SiteContents.Find(Keys[i]);
            if(item!=null){item.Value=Values[i];item.UpdatedAt=DateTime.UtcNow;}
        }
        _db.SaveChanges();
        TempData["Success"]="Content updated successfully.";
        return RedirectToPage(new{sub=Subdomain});
    }
}
