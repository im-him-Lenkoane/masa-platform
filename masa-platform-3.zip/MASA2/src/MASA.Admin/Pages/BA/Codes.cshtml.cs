using MASA.Shared.Data;
using MASA.Shared.Helpers;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.BA;
public class BACodesModel : PageModel {
    private readonly MasaDbContext _db;
    public List<BaAccessCode> Codes{get;set;}=new();
    public List<BaCourse> Courses{get;set;}=new();
    public BACodesModel(MasaDbContext db)=>_db=db;
    public void OnGet(){Codes=_db.BaAccessCodes.OrderByDescending(c=>c.CreatedAt).Take(100).ToList();Courses=_db.BaCourses.Where(c=>c.IsPublished).ToList();}
    public IActionResult OnPostGenerate(int? CourseId,int Count){
        for(int i=0;i<Math.Min(Count,100);i++){
            _db.BaAccessCodes.Add(new BaAccessCode{Code=CaseHelper.GenerateAccessCode(),CourseId=CourseId==0?null:CourseId,ExpiresAt=DateTime.UtcNow.AddMonths(6)});
        }
        _db.SaveChanges();TempData["Success"]=$"{Count} access code(s) generated.";return RedirectToPage();
    }
}
