using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.BA;
public class BACoursesModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public List<BaCourse> Courses{get;set;}=new();
    public BACoursesModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(){Courses=_db.BaCourses.Include(c=>c.Enrolments).Include(c=>c.Banner).OrderBy(c=>c.Title).ToList();}
    public async Task<IActionResult> OnPostAddAsync(string Title,string? Category,string? Description,int DurationWeeks,IFormFile? BannerFile){
        int? bannerId=null;
        if(BannerFile!=null&&BannerFile.Length>0){
            using var s=BannerFile.OpenReadStream();
            var(k,u)=await _media.UploadAsync(s,BannerFile.FileName,"ba","banner",BannerFile.ContentType);
            bannerId=_db.MediaAssets.First(a=>a.S3Key==k).Id;
        }
        _db.BaCourses.Add(new BaCourse{Title=Title,Category=Category??"",Description=Description??"",DurationWeeks=DurationWeeks,BannerAssetId=bannerId});
        await _db.SaveChangesAsync();TempData["Success"]="Course added.";return RedirectToPage();
    }
    public IActionResult OnPostPublish(int Id){var c=_db.BaCourses.Find(Id);if(c!=null){c.IsPublished=!c.IsPublished;_db.SaveChanges();}return RedirectToPage();}
}
