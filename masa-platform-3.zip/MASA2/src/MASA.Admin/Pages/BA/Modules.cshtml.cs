using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.BA;
public class BAModulesModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public BaCourse? Course{get;set;}
    public List<BaModule> Modules{get;set;}=new();
    public int CourseId{get;set;}
    public BAModulesModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(int courseId){CourseId=courseId;Course=_db.BaCourses.Find(courseId);Modules=_db.BaModules.Include(m=>m.Lessons).ThenInclude(l=>l.Asset).Where(m=>m.CourseId==courseId).OrderBy(m=>m.SortOrder).ToList();}
    public IActionResult OnPostAddModule(int CourseId,string Title,int SortOrder){_db.BaModules.Add(new BaModule{CourseId=CourseId,Title=Title,SortOrder=SortOrder});_db.SaveChanges();TempData["Success"]="Module added.";return RedirectToPage(new{courseId=CourseId});}
    public IActionResult OnPostDeleteModule(int ModuleId){var m=_db.BaModules.Find(ModuleId);int cid=m?.CourseId??0;if(m!=null){_db.BaModules.Remove(m);_db.SaveChanges();}return RedirectToPage(new{courseId=cid});}
    public async Task<IActionResult> OnPostAddLessonAsync(int ModuleId,string LessonTitle,string LessonType,IFormFile? LessonFile,string? VideoUrl,int Duration){
        var mod=_db.BaModules.Find(ModuleId);
        int? assetId=null;
        if(LessonFile!=null&&LessonFile.Length>0){using var s=LessonFile.OpenReadStream();var(k,u)=await _media.UploadAsync(s,LessonFile.FileName,"ba","content",LessonFile.ContentType);assetId=_db.MediaAssets.First(a=>a.S3Key==k).Id;}
        _db.BaLessons.Add(new BaLesson{ModuleId=ModuleId,Title=LessonTitle,LessonType=LessonType,MediaAssetId=assetId,VideoUrl=VideoUrl??"",DurationMinutes=Duration});
        await _db.SaveChangesAsync();TempData["Success"]="Lesson added.";return RedirectToPage(new{courseId=mod?.CourseId??0});
    }
    public IActionResult OnPostDeleteLesson(int LessonId){var l=_db.BaLessons.Find(LessonId);int cid=_db.BaModules.Find(l?.ModuleId??0)?.CourseId??0;if(l!=null){_db.BaLessons.Remove(l);_db.SaveChanges();}return RedirectToPage(new{courseId=cid});}
}
