using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.BA;
public class BAEnrolmentsModel : PageModel {
    private readonly MasaDbContext _db;
    public List<BaEnrolment> Enrolments{get;set;}=new();
    public BAEnrolmentsModel(MasaDbContext db)=>_db=db;
    public void OnGet(){Enrolments=_db.BaEnrolments.Include(e=>e.Member).Include(e=>e.Course).OrderByDescending(e=>e.EnrolledAt).ToList();}
}
