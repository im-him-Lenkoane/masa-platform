using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.IIS;
public class IISTypesModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public List<CaseType> Types{get;set;}=new();
    public IISTypesModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(){Types=_db.CaseTypes.Include(t=>t.Icon).OrderBy(t=>t.Subdomain).ThenBy(t=>t.SortOrder).ToList();}
    public async Task<IActionResult> OnPostAddAsync(string Name,string Subdomain,string? Description,IFormFile? IconFile){
        int? iconId=null;
        if(IconFile!=null&&IconFile.Length>0){
            using var s=IconFile.OpenReadStream();
            var(k,u)=await _media.UploadAsync(s,IconFile.FileName,Subdomain,"icon",IconFile.ContentType);
            iconId=_db.MediaAssets.First(a=>a.S3Key==k).Id;
        }
        _db.CaseTypes.Add(new CaseType{Name=Name,Subdomain=Subdomain,Description=Description??"",IconAssetId=iconId});
        await _db.SaveChangesAsync();TempData["Success"]="Case type added.";return RedirectToPage();
    }
    public IActionResult OnPostDelete(int Id){var t=_db.CaseTypes.Find(Id);if(t!=null){_db.CaseTypes.Remove(t);_db.SaveChanges();}return RedirectToPage();}
}
