using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.IIS;
public class IISCasesModel : PageModel {
    private readonly MasaDbContext _db;
    public List<CaseSubmission> Cases{get;set;}=new();
    public string StatusFilter{get;set;}="all";
    public IISCasesModel(MasaDbContext db)=>_db=db;
    public void OnGet(string? status){
        StatusFilter=status??"all";
        var q=_db.CaseSubmissions.Include(c=>c.CaseType).Where(c=>c.Subdomain=="iis");
        if(StatusFilter!="all") q=q.Where(c=>c.Status==StatusFilter);
        Cases=q.OrderByDescending(c=>c.SubmittedAt).ToList();
    }
}
