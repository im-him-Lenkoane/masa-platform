using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.IIS;
public class CaseViewModel:PageModel{private readonly MasaDbContext _db;
public CaseSubmission? Case{get;set;}
public CaseViewModel(MasaDbContext db)=>_db=db;
public void OnGet(int id){Case=_db.CaseSubmissions.Include(c=>c.CaseType).FirstOrDefault(c=>c.Id==id);}
public IActionResult OnPost(int CaseId,string Status,string? AgentNotes){
    var c=_db.CaseSubmissions.Find(CaseId);
    if(c!=null){c.Status=Status;c.AgentNotes=AgentNotes??"";c.UpdatedAt=DateTime.UtcNow;_db.SaveChanges();}
    TempData["Success"]="Case updated.";return RedirectToPage(new{id=CaseId});}}
