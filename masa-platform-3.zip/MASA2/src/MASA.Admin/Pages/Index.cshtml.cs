using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages;
public class IndexModel : PageModel {
    private readonly MasaDbContext _db;
    public int TotalMembers{get;set;}
    public int TotalCases{get;set;}
    public int TotalSubjects{get;set;}
    public int TotalCourses{get;set;}
    public List<CaseSubmission> RecentCases{get;set;}=new();
    public IndexModel(MasaDbContext db)=>_db=db;
    public void OnGet(){
        TotalMembers=_db.Members.Count();
        TotalCases=_db.CaseSubmissions.Count(c=>c.Status!="closed");
        TotalSubjects=_db.EduSubjects.Count();
        TotalCourses=_db.BaCourses.Count();
        RecentCases=_db.CaseSubmissions.OrderByDescending(c=>c.SubmittedAt).Take(5).ToList();
    }
}
