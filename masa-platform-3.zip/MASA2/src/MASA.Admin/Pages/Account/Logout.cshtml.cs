using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Account;
public class LogoutModel : PageModel {
    public IActionResult OnGet(){HttpContext.Session.Clear();return RedirectToPage("/Account/Login");}
}
