using MASA.Shared.Data;
using MASA.Shared.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Account;
public class LoginModel : PageModel {
    private readonly MasaDbContext _db;
    public LoginModel(MasaDbContext db)=>_db=db;
    public void OnGet(){}
    public IActionResult OnPost(string Email,string Password){
        var user=_db.AdminUsers.Include(u=>u.Role).FirstOrDefault(u=>u.Email==Email&&u.IsActive);
        if(user==null||!PasswordHelper.Verify(Password,user.PasswordHash)){
            TempData["Error"]="Invalid email or password.";return Page();
        }
        user.LastLoginAt=DateTime.UtcNow;_db.SaveChanges();
        HttpContext.Session.SetInt32("AdminUserId",user.Id);
        HttpContext.Session.SetString("AdminEmail",user.Email);
        HttpContext.Session.SetString("AdminRole",user.Role?.Slug??"");
        HttpContext.Session.SetString("AdminName",$"{user.FirstName} {user.LastName}");
        return RedirectToPage("/Index");
    }
}
