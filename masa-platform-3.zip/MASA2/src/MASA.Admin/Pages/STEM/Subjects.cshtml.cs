using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.STEM;
public class STEMSubjectsModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public List<StemSubject> Subjects{get;set;}=new();
    public STEMSubjectsModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(){Subjects=_db.StemSubjects.Include(s=>s.Icon).Include(s=>s.Topics).OrderBy(s=>s.SortOrder).ToList();}
    public async Task<IActionResult> OnPostAddAsync(string Name,string? Description,IFormFile? IconFile,IFormFile? BannerFile){
        int? iconId=null,bannerId=null;
        if(IconFile!=null&&IconFile.Length>0){using var s=IconFile.OpenReadStream();var(k,u)=await _media.UploadAsync(s,IconFile.FileName,"stem","icon",IconFile.ContentType);iconId=_db.MediaAssets.First(a=>a.S3Key==k).Id;}
        if(BannerFile!=null&&BannerFile.Length>0){using var s=BannerFile.OpenReadStream();var(k,u)=await _media.UploadAsync(s,BannerFile.FileName,"stem","banner",BannerFile.ContentType);bannerId=_db.MediaAssets.First(a=>a.S3Key==k).Id;}
        _db.StemSubjects.Add(new StemSubject{Name=Name,Description=Description??"",IconAssetId=iconId,BannerAssetId=bannerId,IsPublished=true});
        await _db.SaveChangesAsync();TempData["Success"]="Subject added.";return RedirectToPage();
    }
    public IActionResult OnPostDelete(int Id){var s=_db.StemSubjects.Find(Id);if(s!=null){_db.StemSubjects.Remove(s);_db.SaveChanges();}return RedirectToPage();}
}
