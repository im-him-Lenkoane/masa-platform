using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.STEM;
public class STEMTopicsModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public StemSubject? Subject{get;set;}
    public List<StemTopic> Topics{get;set;}=new();
    public int SubjectId{get;set;}
    public STEMTopicsModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(int subjectId){SubjectId=subjectId;Subject=_db.StemSubjects.Find(subjectId);Topics=_db.StemTopics.Include(t=>t.Image).Where(t=>t.SubjectId==subjectId).OrderBy(t=>t.SortOrder).ToList();}
    public async Task<IActionResult> OnPostAddAsync(int SubjectId,string Title,string? Body,string? DidYouKnow,string? VideoUrl,IFormFile? ImageFile){
        int? imgId=null;
        if(ImageFile!=null&&ImageFile.Length>0){using var s=ImageFile.OpenReadStream();var(k,u)=await _media.UploadAsync(s,ImageFile.FileName,"stem","image",ImageFile.ContentType);imgId=_db.MediaAssets.First(a=>a.S3Key==k).Id;}
        _db.StemTopics.Add(new StemTopic{SubjectId=SubjectId,Title=Title,Body=Body??"",DidYouKnow=DidYouKnow??"",VideoUrl=VideoUrl??"",ImageAssetId=imgId,IsPublished=true});
        await _db.SaveChangesAsync();TempData["Success"]="Topic added.";return RedirectToPage(new{subjectId=SubjectId});
    }
    public IActionResult OnPostDelete(int TopicId){var t=_db.StemTopics.Find(TopicId);if(t!=null){_db.StemTopics.Remove(t);_db.SaveChanges();}return RedirectToPage(new{subjectId=t?.SubjectId??0});}
}
