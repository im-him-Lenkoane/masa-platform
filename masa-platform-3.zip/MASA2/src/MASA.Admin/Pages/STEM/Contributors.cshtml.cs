using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.STEM;
public class ContributorsAdminModel : PageModel {
    private readonly MasaDbContext _db;
    public List<Contributor> Contributors{get;set;}=new();
    public ContributorsAdminModel(MasaDbContext db)=>_db=db;
    public void OnGet(){Contributors=_db.Contributors.OrderByDescending(c=>c.AppliedAt).ToList();}
    public IActionResult OnPostApprove(int Id){var c=_db.Contributors.Find(Id);if(c!=null){c.Status="approved";_db.SaveChanges();}return RedirectToPage();}
    public IActionResult OnPostReject(int Id){var c=_db.Contributors.Find(Id);if(c!=null){c.Status="rejected";_db.SaveChanges();}return RedirectToPage();}
}
