using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Admin.Pages.MINM;
public class MINMSubjectsModel : PageModel {
    private readonly MasaDbContext _db;
    public List<EduSubject> Subjects{get;set;}=new();
    public MINMSubjectsModel(MasaDbContext db)=>_db=db;
    public void OnGet(){Subjects=_db.EduSubjects.Include(s=>s.Topics).Include(s=>s.Grade).Include(s=>s.Faculty).Where(s=>s.Subdomain=="minm").OrderBy(s=>s.Level).ThenBy(s=>s.SortOrder).ToList();}
}
