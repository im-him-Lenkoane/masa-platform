using MASA.Shared.Data;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Publications;
public class PublicationsAdminModel : PageModel {
    private readonly MasaDbContext _db; private readonly IMediaService _media;
    public List<Publication> Publications{get;set;}=new();
    public PublicationsAdminModel(MasaDbContext db,IMediaService media){_db=db;_media=media;}
    public void OnGet(){Publications=_db.Publications.OrderByDescending(p=>p.PublishedAt).ToList();}
    public async Task<IActionResult> OnPostAddAsync(string Title,string Subdomain,string? Abstract,IFormFile? DocFile,string? ExternalUrl){
        int? docId=null;
        if(DocFile!=null&&DocFile.Length>0){
            using var s=DocFile.OpenReadStream();
            var(k,u)=await _media.UploadAsync(s,DocFile.FileName,Subdomain,"document",DocFile.ContentType);
            docId=_db.MediaAssets.First(a=>a.S3Key==k).Id;
        }
        _db.Publications.Add(new Publication{Title=Title,Subdomain=Subdomain,Abstract=Abstract??"",DocumentAssetId=docId,ExternalUrl=ExternalUrl??"",IsPublished=true});
        await _db.SaveChangesAsync();TempData["Success"]="Publication added.";return RedirectToPage();
    }
    public IActionResult OnPostDelete(int Id){var p=_db.Publications.Find(Id);if(p!=null){_db.Publications.Remove(p);_db.SaveChanges();}return RedirectToPage();}
}
