using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Admin.Pages.Publications;
public class PubCreateModel:PageModel{private readonly MasaDbContext _db;
public PubCreateModel(MasaDbContext db)=>_db=db;public void OnGet(){}
public IActionResult OnPost(string Title,string? Abstract,string Subdomain,string? DocUrl,string? ExternalUrl,bool IsPublished){
    int? docId=null;
    if(!string.IsNullOrEmpty(DocUrl)){var a=_db.MediaAssets.FirstOrDefault(x=>x.PublicUrl==DocUrl);docId=a?.Id;}
    _db.Publications.Add(new Publication{Title=Title,Abstract=Abstract??"",Subdomain=Subdomain,DocumentAssetId=docId,ExternalUrl=ExternalUrl??"",IsPublished=IsPublished});
    _db.SaveChanges();TempData["Success"]="Publication saved.";return RedirectToPage("/Publications/Index");}}
