using MASA.Shared.Data;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Edu.Pages.Api;
public class TutorApiModel : PageModel {
    private readonly IClaudeService _claude;
    public TutorApiModel(IClaudeService claude)=>_claude=claude;
    public async Task<IActionResult> OnPostAsync([FromBody]TutorRequest req){
        var answer=await _claude.TutorAsync(req.Subject,req.Topic,req.Level,req.Question);
        return new JsonResult(new{answer});
    }
}
public record TutorRequest(string Subject,string Topic,string Level,string Question);
