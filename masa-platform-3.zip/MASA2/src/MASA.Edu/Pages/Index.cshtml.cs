using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Edu.Pages;
public class IndexModel : BasePage {
    public List<EduGrade> Grades{get;set;}=new();
    public List<EduFaculty> Faculties{get;set;}=new();
    public string HeroBannerUrl{get;set;}="";
    public IndexModel(MasaDbContext db):base(db){}
    public void OnGet(){
        Grades=Db.EduGrades.Where(g=>g.Subdomain=="edu"&&g.Level=="school"&&g.IsActive).OrderBy(g=>g.SortOrder).ToList();
        Faculties=Db.EduFaculties.Include(f=>f.Icon).Where(f=>f.Subdomain=="edu"&&f.IsActive).OrderBy(f=>f.SortOrder).ToList();
        HeroBannerUrl=Db.MediaAssets.Where(a=>a.Subdomain=="edu"&&a.Tag=="hero_banner").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
    }
}
