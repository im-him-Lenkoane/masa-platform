using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc.RazorPages;using Microsoft.EntityFrameworkCore;
namespace MASA.Edu.Pages;
public class SchoolModel:BasePage{public List<EduGrade> Grades{get;set;}=new();
public SchoolModel(MasaDbContext db):base(db){}
public void OnGet(){Grades=Db.EduGrades.Include(g=>g.Subjects).Where(g=>g.Subdomain=="edu"&&g.Level=="school"&&g.IsActive).OrderBy(g=>g.SortOrder).ToList();}}
