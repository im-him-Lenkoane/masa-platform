using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Edu.Pages;
public class EduAboutModel : BasePage {
    public string AboutText{get;set;}="";
    public List<TeamMember> Team{get;set;}=new();
    public EduAboutModel(MasaDbContext db):base(db){}
    public void OnGet(){
        AboutText=GetContent("edu","about","MASA Education serves FET Grade 10-12 learners and tertiary STEM students with quality content, AI tutoring, and live sessions.");
        Team=Db.TeamMembers.Include(t=>t.Photo).Where(t=>t.Subdomain=="edu"&&t.IsActive).OrderBy(t=>t.SortOrder).ToList();
    }
}
