using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Edu.Pages;
public class EventsModel : BasePage {
    public List<EduEvent> Events{get;set;}=new();
    public EventsModel(MasaDbContext db):base(db){}
    public void OnGet(){Events=Db.EduEvents.Where(e=>e.Subdomain=="edu"&&e.IsPublished&&e.EventDate>=DateTime.UtcNow.AddDays(-1)).OrderBy(e=>e.EventDate).ToList();}
}
