using MASA.Shared.Data;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc.RazorPages;using Microsoft.EntityFrameworkCore;
namespace MASA.Edu.Pages;
public class TertiaryModel:BasePage{public List<EduFaculty> Faculties{get;set;}=new();
public TertiaryModel(MasaDbContext db):base(db){}
public void OnGet(){Faculties=Db.EduFaculties.Include(f=>f.Icon).Include(f=>f.Subjects).Where(f=>f.Subdomain=="edu"&&f.IsActive).OrderBy(f=>f.SortOrder).ToList();}}
