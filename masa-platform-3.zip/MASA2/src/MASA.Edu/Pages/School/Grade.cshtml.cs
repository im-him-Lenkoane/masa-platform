using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Edu.Pages.School;
public class GradeModel : BasePage {
    public EduGrade? Grade{get;set;}
    public List<EduSubject> Subjects{get;set;}=new();
    public GradeModel(MasaDbContext db):base(db){}
    public void OnGet(int gradeId){
        Grade=Db.EduGrades.Find(gradeId);
        Subjects=Db.EduSubjects.Include(s=>s.Banner).Include(s=>s.Topics).Where(s=>s.GradeId==gradeId&&s.IsPublished).OrderBy(s=>s.SortOrder).ToList();
    }
}
