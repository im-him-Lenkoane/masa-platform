using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Edu.Pages;
public class SessionsModel : BasePage {
    public List<LiveSession> LiveNow{get;set;}=new();
    public List<LiveSession> Upcoming{get;set;}=new();
    public SessionsModel(MasaDbContext db):base(db){}
    public void OnGet(){
        LiveNow=Db.LiveSessions.Where(s=>s.Subdomain=="edu"&&s.IsLive&&s.IsPublished).ToList();
        Upcoming=Db.LiveSessions.Where(s=>s.Subdomain=="edu"&&!s.IsLive&&s.IsPublished&&s.SessionDate>=DateTime.UtcNow).OrderBy(s=>s.SessionDate).Take(10).ToList();
    }
}
