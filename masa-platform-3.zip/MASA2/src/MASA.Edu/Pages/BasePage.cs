using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Edu.Pages;
public class BasePage : PageModel {
    protected readonly MasaDbContext Db;
    public BasePage(MasaDbContext db) { Db = db; }
    public override void OnPageHandlerExecuting(Microsoft.AspNetCore.Mvc.Filters.PageHandlerExecutingContext ctx) {
        base.OnPageHandlerExecuting(ctx);
        ViewData["Menus"] = Db.SiteMenus.Where(m=>m.Subdomain=="edu"&&m.IsActive).OrderBy(m=>m.SortOrder).ToList();
        var logo = Db.MediaAssets.Where(a=>a.Subdomain=="global"&&a.Category=="logo").OrderByDescending(a=>a.UploadedAt).FirstOrDefault();
        ViewData["LogoUrl"] = logo?.PublicUrl ?? "";
    }
    public string GetContent(string page, string key, string fallback="") {
        var item = Db.SiteContents.FirstOrDefault(c=>c.Subdomain=="edu"&&c.Page==page&&c.ElementKey==key);
        return item?.Value ?? fallback;
    }
}
