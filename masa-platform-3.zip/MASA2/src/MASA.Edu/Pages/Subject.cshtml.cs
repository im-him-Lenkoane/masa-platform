using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Edu.Pages;
public class SubjectPageModel : BasePage {
    public EduSubject? Subject{get;set;}
    public List<EduTopic> Topics{get;set;}=new();
    public MediaAsset? TextbookAsset{get;set;}
    public MediaAsset? NotesAsset{get;set;}
    public List<EduEvent> Events{get;set;}=new();
    public string AiIconUrl{get;set;}="";
    public SubjectPageModel(MasaDbContext db):base(db){}
    public IActionResult OnGet(int subjectId){
        Subject=Db.EduSubjects.Include(s=>s.Banner).FirstOrDefault(s=>s.Id==subjectId&&s.IsPublished);
        if(Subject==null)return RedirectToPage("/Index");
        Topics=Db.EduTopics.Include(t=>t.Contents).ThenInclude(c=>c.Asset).Where(t=>t.SubjectId==subjectId).OrderBy(t=>t.SortOrder).ToList();
        if(Subject.TextbookAssetId.HasValue) TextbookAsset=Db.MediaAssets.Find(Subject.TextbookAssetId.Value);
        if(Subject.NotesAssetId.HasValue) NotesAsset=Db.MediaAssets.Find(Subject.NotesAssetId.Value);
        Events=Db.EduEvents.Where(e=>e.SubjectId==subjectId&&e.IsPublished&&e.EventDate>=DateTime.UtcNow).ToList();
        AiIconUrl=Db.MediaAssets.Where(a=>a.Tag=="icon_ai").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
        return Page();
    }
}
