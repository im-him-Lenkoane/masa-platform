using MASA.Shared.Data;using MASA.Shared.Services;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Health.Pages.Api;
[IgnoreAntiforgeryToken]
public class TutorApiModel:PageModel{private readonly IClaudeService _claude;
public TutorApiModel(MasaDbContext db,IClaudeService claude){_claude=claude;}
public async Task<IActionResult> OnPostAsync([FromBody]TutorRequest req){
    var sys="You are MASA Health support AI. Provide empathetic, accurate health information relevant to South Africa. Always recommend professional medical advice for specific health concerns.";
    var answer=await _claude.ChatAsync(sys,req.Question??"");
    return new JsonResult(new{answer});}
}
public record TutorRequest(string? Subject,string? Topic,string? Level,string? Question);
