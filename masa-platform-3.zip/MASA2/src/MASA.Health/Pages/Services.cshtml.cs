using MASA.Shared.Data;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Health.Pages;
public class HealthServicesModel:BasePage{public HealthServicesModel(MasaDbContext db):base(db){}public void OnGet(){}}
