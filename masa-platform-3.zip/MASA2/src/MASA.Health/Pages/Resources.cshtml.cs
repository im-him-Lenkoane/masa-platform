using MASA.Shared.Data;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Health.Pages;
public class HealthResourcesModel:BasePage{public HealthResourcesModel(MasaDbContext db):base(db){}public void OnGet(){}}
