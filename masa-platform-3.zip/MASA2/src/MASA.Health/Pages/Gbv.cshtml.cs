using MASA.Shared.Data;using MASA.Shared.Helpers;using MASA.Shared.Models;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;using Microsoft.EntityFrameworkCore;
namespace MASA.Health.Pages;
public class GbvModel:BasePage{
    public List<HealthContent> Contents{get;set;}=new();
    public bool RequiresAgeVerification{get;set;}=false;
    public bool IsVerified{get;set;}=false;
    public GbvModel(MasaDbContext db):base(db){}
    public void OnGet(){
        IsVerified=HttpContext.Session.GetInt32("AgeVerified")==1||!RequiresAgeVerification;
        if(IsVerified)Contents=Db.HealthContents.Include(c=>c.Banner).Where(c=>c.Category=="gbv"&&c.IsPublished).OrderBy(c=>c.SortOrder).ToList();
    }
    public IActionResult OnPostVerify(string SaId){
        var result=SAIdValidator.Validate(SaId);
        if(!result.IsValid){TempData["AgeError"]=result.Error;return Page();}
        if(result.Age<18){TempData["AgeError"]="This content is for adults 18+ only.";return Page();}
        HttpContext.Session.SetInt32("AgeVerified",1);
        return RedirectToPage();
    }
}
