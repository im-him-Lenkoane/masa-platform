using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Health.Pages;
public class HealthAboutModel : BasePage {
    public string AboutText{get;set;}="";
    public HealthAboutModel(MasaDbContext db):base(db){}
    public void OnGet(){AboutText=GetContent("health","about","Content coming soon.");}
}
