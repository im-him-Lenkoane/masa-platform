using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Health.Pages;
public class FirstAidModel : BasePage {
    public List<HealthContent> Contents{get;set;}=new();
    public FirstAidModel(MasaDbContext db):base(db){}
    public void OnGet(){Contents=Db.HealthContents.Include(c=>c.Banner).Where(c=>c.Category=="firstaid"&&c.IsPublished).OrderBy(c=>c.SortOrder).ToList();}
}
