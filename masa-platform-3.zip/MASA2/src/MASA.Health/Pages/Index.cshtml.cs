using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Health.Pages;
public class IndexModel : BasePage {
    public string HeroBannerUrl{get;set;}="";
    public string SrhrIconUrl{get;set;}="";
    public string GbvIconUrl{get;set;}="";
    public string ChronicIconUrl{get;set;}="";
    public string RareIconUrl{get;set;}="";
    public IndexModel(MasaDbContext db):base(db){}
    public void OnGet(){
        string Icon(string tag)=>Db.MediaAssets.Where(a=>a.Tag==tag).OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
        HeroBannerUrl=Icon("health_hero_banner");
        SrhrIconUrl=Icon("icon_srhr");GbvIconUrl=Icon("icon_gbv");
        ChronicIconUrl=Icon("icon_chronic");RareIconUrl=Icon("icon_rare");
    }
}
