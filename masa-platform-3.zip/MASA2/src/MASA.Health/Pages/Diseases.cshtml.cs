using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Health.Pages;
public class DiseasesModel : BasePage {
    public List<HealthContent> Contents{get;set;}=new();
    public string Category{get;set;}="chronic";
    public DiseasesModel(MasaDbContext db):base(db){}
    public void OnGet(string? cat){Category=cat??"chronic";Contents=Db.HealthContents.Include(c=>c.Banner).Where(c=>c.Category==Category&&c.IsPublished).OrderBy(c=>c.SortOrder).ToList();}
}
