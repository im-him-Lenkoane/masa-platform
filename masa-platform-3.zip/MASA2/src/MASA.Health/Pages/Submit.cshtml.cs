using MASA.Shared.Data;
using MASA.Shared.Helpers;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Health.Pages;
public class HealthSubmitModel : BasePage {
    private readonly IEmailService _email;
    public List<CaseType> CaseTypes{get;set;}=new();
    public HealthSubmitModel(MasaDbContext db,IEmailService email):base(db){_email=email;}
    public void OnGet(){CaseTypes=Db.CaseTypes.Where(c=>c.Subdomain=="health"&&c.IsActive).OrderBy(c=>c.SortOrder).ToList();}
    public async Task<IActionResult> OnPostAsync(int CaseTypeId,string Name,string Email,string? Phone,string? SaId,string Description){
        CaseTypes=Db.CaseTypes.Where(c=>c.Subdomain=="health"&&c.IsActive).ToList();
        var caseNo=CaseHelper.GenerateCaseNumber("HEALTH");
        Db.CaseSubmissions.Add(new CaseSubmission{CaseNumber=caseNo,Subdomain="health",CaseTypeId=CaseTypeId,SubmitterName=Name,SubmitterEmail=Email,SubmitterPhone=Phone??"",SaIdNumber=SaId,Description=Description});
        if(!Db.Members.Any(m=>m.Email==Email)){
            var pwd=Guid.NewGuid().ToString()[..8];
            Db.Members.Add(new Member{Email=Email,FirstName=Name.Split(' ').First(),LastName=string.Join(" ",Name.Split(' ').Skip(1)),Phone=Phone??"",MembershipNumber=CaseHelper.GenerateMembershipNumber(),PasswordHash=PasswordHelper.Hash(pwd)});
        }
        await Db.SaveChangesAsync();
        await _email.SendAsync(Email,"MASA Health — Case Received",$"<h2>Hi {Name},</h2><p>Your health case <strong>{caseNo}</strong> has been received. Our team will be in touch.</p><p>MASA Health</p>");
        TempData["Success"]=$"Case {caseNo} submitted. Check your email for confirmation.";
        return RedirectToPage();
    }
}
