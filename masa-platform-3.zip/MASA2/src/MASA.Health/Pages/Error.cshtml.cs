using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.Health.Pages;
[ResponseCache(Duration=0,Location=ResponseCacheLocation.None,NoStore=true)]
[IgnoreAntiforgeryToken]
public class ErrorModel : PageModel {
    public int Code{get;set;}=500;
    public string Title{get;set;}="Error";
    public string Message{get;set;}="An error occurred.";
    public void OnGet(int? code){Code=code??500;Title=Code==404?"Page Not Found":Code==403?"Access Denied":"Error";Message=Code==404?"The page you are looking for does not exist.":"An unexpected error occurred.";}
}
