using MASA.Shared.Data;
using MASA.Shared.Helpers;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.Health.Pages;
public class SRHRModel : BasePage {
    public bool AgeVerified{get;set;}
    public bool HasContent{get;set;}
    public List<HealthContent> Contents{get;set;}=new();
    public SRHRModel(MasaDbContext db):base(db){}
    public void OnGet(){
        AgeVerified=HttpContext.Session.GetInt32("AgeVerified")==1;
        Contents=Db.HealthContents.Include(c=>c.Banner).Where(c=>c.Category=="srhr"&&c.IsPublished).OrderBy(c=>c.SortOrder).ToList();
        HasContent=Contents.Any();
    }
    public IActionResult OnPost(string SaId){
        var result=SAIdValidator.Validate(SaId);
        if(!result.IsValid){TempData["AgeError"]=result.Error;return Page();}
        if(result.Age<18){TempData["AgeError"]="You must be 18 or older to access this content.";return Page();}
        HttpContext.Session.SetInt32("AgeVerified",1);
        return RedirectToPage();
    }
}
