using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.BA.Pages;
public class ProgrammesModel : BasePage {
    public List<BaCourse> Courses{get;set;}=new();
    public List<string> Categories{get;set;}=new();
    public string? CatFilter{get;set;}
    public ProgrammesModel(MasaDbContext db):base(db){}
    public void OnGet(string? cat){
        CatFilter=cat;
        var q=Db.BaCourses.Include(c=>c.Banner).Where(c=>c.IsPublished);
        if(!string.IsNullOrEmpty(cat)) q=q.Where(c=>c.Category==cat);
        Courses=q.OrderBy(c=>c.Category).ThenBy(c=>c.Title).ToList();
        Categories=Db.BaCourses.Where(c=>c.IsPublished&&!string.IsNullOrEmpty(c.Category)).Select(c=>c.Category).Distinct().OrderBy(c=>c).ToList();
    }
}
