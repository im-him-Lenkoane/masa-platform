using MASA.Shared.Data;using MASA.Shared.Helpers;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.BA.Pages;
public class BALoginModel:BasePage{public BALoginModel(MasaDbContext db):base(db){}
public void OnGet(){}
public IActionResult OnPost(string Email,string Password){
    var m=Db.Members.FirstOrDefault(x=>x.Email==Email&&x.HasBaAccess&&x.IsActive);
    if(m==null||!PasswordHelper.Verify(Password,m.PasswordHash)){TempData["Error"]="Invalid credentials.";return Page();}
    HttpContext.Session.SetInt32("MemberId",m.Id);HttpContext.Session.SetString("MemberEmail",m.Email);HttpContext.Session.SetString("MemberName",$"{m.FirstName} {m.LastName}");
    return RedirectToPage("/Dashboard");}}
