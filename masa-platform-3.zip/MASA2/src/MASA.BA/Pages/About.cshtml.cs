using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.BA.Pages;
public class BAAboutModel : BasePage {
    public string AboutText{get;set;}="";
    public BAAboutModel(MasaDbContext db):base(db){}
    public void OnGet(){AboutText=GetContent("ba","about","The Builders Academy provides hands-on training in computer science, physical skills, and trades for South African youth.");}
}
