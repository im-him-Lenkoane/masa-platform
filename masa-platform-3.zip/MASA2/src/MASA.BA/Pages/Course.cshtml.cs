using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.BA.Pages;
public class CoursePageModel : BasePage {
    public BaCourse? Course{get;set;}
    public List<BaModule> Modules{get;set;}=new();
    public CoursePageModel(MasaDbContext db):base(db){}
    public IActionResult OnGet(int courseId){
        Course=Db.BaCourses.Include(c=>c.Banner).FirstOrDefault(c=>c.Id==courseId&&c.IsPublished);
        if(Course==null)return RedirectToPage("/Index");
        Modules=Db.BaModules.Include(m=>m.Lessons).Where(m=>m.CourseId==courseId).OrderBy(m=>m.SortOrder).ToList();
        return Page();
    }
}
