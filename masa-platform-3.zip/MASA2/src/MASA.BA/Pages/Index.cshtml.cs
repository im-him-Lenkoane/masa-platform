using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.BA.Pages;
public class IndexModel : BasePage {
    public List<BaCourse> Courses{get;set;}=new();
    public string HeroBannerUrl{get;set;}="";
    public IndexModel(MasaDbContext db):base(db){}
    public void OnGet(){
        Courses=Db.BaCourses.Include(c=>c.Banner).Where(c=>c.IsPublished).OrderBy(c=>c.Category).Take(9).ToList();
        HeroBannerUrl=Db.MediaAssets.Where(a=>a.Subdomain=="ba"&&a.Tag=="hero_banner").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
    }
}
