using MASA.Shared.Data;
using MASA.Shared.Helpers;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.BA.Pages;
public class EnrolModel : BasePage {
    public EnrolModel(MasaDbContext db):base(db){}
    public void OnGet(){}
    public IActionResult OnPost(string Code,string Email,string Password){
        var code=Db.BaAccessCodes.FirstOrDefault(c=>c.Code==Code.ToUpper()&&!c.IsUsed&&(c.ExpiresAt==null||c.ExpiresAt>DateTime.UtcNow));
        if(code==null){TempData["Error"]="Invalid or expired access code.";return Page();}
        var member=Db.Members.FirstOrDefault(m=>m.Email==Email);
        if(member==null){member=new Member{Email=Email,MembershipNumber=CaseHelper.GenerateMembershipNumber(),PasswordHash=PasswordHelper.Hash(Password),HasBaAccess=true};Db.Members.Add(member);}
        else{member.HasBaAccess=true;member.PasswordHash=PasswordHelper.Hash(Password);}
        Db.SaveChanges();
        var enrolment=new BaEnrolment{CourseId=code.CourseId??Db.BaCourses.First(c=>c.IsPublished).Id,MemberId=member.Id};
        Db.BaEnrolments.Add(enrolment);
        code.IsUsed=true;code.UsedByMemberId=member.Id;code.UsedAt=DateTime.UtcNow;
        Db.SaveChanges();
        HttpContext.Session.SetInt32("MemberId",member.Id);
        HttpContext.Session.SetString("MemberEmail",member.Email);
        TempData["Success"]="Enrolment successful! You are now logged in.";
        return RedirectToPage("/Dashboard");
    }
}
