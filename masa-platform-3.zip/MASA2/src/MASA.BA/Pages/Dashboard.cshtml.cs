using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.BA.Pages;
public class DashboardModel : BasePage {
    public bool IsLoggedIn{get;set;}
    public string MemberName{get;set;}="";
    public List<BaEnrolment> Enrolments{get;set;}=new();
    public DashboardModel(MasaDbContext db):base(db){}
    public void OnGet(){
        var mid=HttpContext.Session.GetInt32("MemberId");
        IsLoggedIn=mid.HasValue;
        if(mid.HasValue){
            var m=Db.Members.Find(mid.Value);
            MemberName=m?.FirstName??"Student";
            Enrolments=Db.BaEnrolments.Include(e=>e.Course).Where(e=>e.MemberId==mid.Value).ToList();
        }
    }
}
