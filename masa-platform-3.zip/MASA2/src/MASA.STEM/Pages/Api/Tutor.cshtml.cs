using MASA.Shared.Data;using MASA.Shared.Services;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.STEM.Pages.Api;
[IgnoreAntiforgeryToken]
public class TutorApiModel:PageModel{private readonly IClaudeService _claude;
public TutorApiModel(MasaDbContext db,IClaudeService claude){_claude=claude;}
public async Task<IActionResult> OnPostAsync([FromBody]TutorRequest req){var sys="You are MASA STEM tutor. Help youth learn STEM concepts in a fun engaging way. Use real South African examples.";var answer=await _claude.ChatAsync(sys,req.Question??"");return new JsonResult(new{answer});}
}
public record TutorRequest(string? Subject,string? Topic,string? Level,string? Question);
