using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.STEM.Pages;
public class StemSubjectPage : BasePage {
    public StemSubject? Subject{get;set;}
    public List<StemTopic> Topics{get;set;}=new();
    public StemSubjectPage(MasaDbContext db):base(db){}
    public IActionResult OnGet(int subjectId){
        Subject=Db.StemSubjects.Include(s=>s.Banner).FirstOrDefault(s=>s.Id==subjectId&&s.IsPublished);
        if(Subject==null)return RedirectToPage("/Index");
        Topics=Db.StemTopics.Include(t=>t.Image).Where(t=>t.SubjectId==subjectId&&t.IsPublished).OrderBy(t=>t.SortOrder).ToList();
        return Page();
    }
}
