using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.STEM.Pages;
public class IndexModel : BasePage {
    public List<StemSubject> Subjects{get;set;}=new();
    public string HeroBannerUrl{get;set;}="";
    public IndexModel(MasaDbContext db):base(db){}
    public void OnGet(){
        Subjects=Db.StemSubjects.Include(s=>s.Icon).Include(s=>s.Topics).Where(s=>s.IsPublished).OrderBy(s=>s.SortOrder).ToList();
        HeroBannerUrl=Db.MediaAssets.Where(a=>a.Subdomain=="stem"&&a.Tag=="hero_banner").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
    }
}
