using MASA.Shared.Data;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.STEM.Pages;
public class STEMResourcesModel:BasePage{public STEMResourcesModel(MasaDbContext db):base(db){}public void OnGet(){}}
