using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.STEM.Pages;
public class STEMSubjectsListModel : BasePage {
    public List<StemSubject> Subjects{get;set;}=new();
    public STEMSubjectsListModel(MasaDbContext db):base(db){}
    public void OnGet(){Subjects=Db.StemSubjects.Include(s=>s.Icon).Include(s=>s.Topics).Where(s=>s.IsPublished).OrderBy(s=>s.SortOrder).ToList();}
}
