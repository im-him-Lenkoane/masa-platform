using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.STEM.Pages;
public class STEMAboutModel : BasePage {
    public string AboutText{get;set;}="";
    public STEMAboutModel(MasaDbContext db):base(db){}
    public void OnGet(){AboutText=GetContent("stem","about","Content coming soon.");}
}
