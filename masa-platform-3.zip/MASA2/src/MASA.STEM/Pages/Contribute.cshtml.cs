using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.STEM.Pages;
public class ContributeModel : BasePage {
    public ContributeModel(MasaDbContext db):base(db){}
    public void OnGet(){}
    public IActionResult OnPost(string Name,string Email,string Expertise,string? SampleUrl,string Motivation){
        Db.Contributors.Add(new Contributor{Name=Name,Email=Email,Expertise=Expertise,SampleUrl=SampleUrl??"",Motivation=Motivation});
        Db.SaveChanges();
        TempData["Success"]="Application submitted. We will review and be in touch.";
        return RedirectToPage();
    }
}
