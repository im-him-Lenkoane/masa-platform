using MASA.Shared.Data;
using MASA.Shared.Helpers;
using MASA.Shared.Models;
using MASA.Shared.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
namespace MASA.IIS.Pages;
public class SubmitModel : BasePage {
    private readonly IEmailService _email;
    private readonly IClaudeService _claude;
    public List<CaseType> CaseTypes{get;set;}=new();
    public int? SelectedTypeId{get;set;}
    public SubmitModel(MasaDbContext db,IEmailService email,IClaudeService claude):base(db){_email=email;_claude=claude;}
    public void OnGet(int? type){SelectedTypeId=type;CaseTypes=Db.CaseTypes.Where(c=>c.Subdomain=="iis"&&c.IsActive).OrderBy(c=>c.SortOrder).ToList();}
    public async Task<IActionResult> OnPostAsync(int CaseTypeId,string Name,string Email,string? Phone,string? SaId,string Description){
        CaseTypes=Db.CaseTypes.Where(c=>c.Subdomain=="iis"&&c.IsActive).ToList();
        var caseNo=CaseHelper.GenerateCaseNumber("IIS");
        var triageJson=await _claude.TriageCaseAsync(CaseTypes.FirstOrDefault(c=>c.Id==CaseTypeId)?.Name??"Unknown",Description);
        int severity=1;string summary="";
        try{var j=JsonDocument.Parse(triageJson);severity=j.RootElement.TryGetProperty("severity",out var sv)?sv.GetInt32():1;summary=j.RootElement.TryGetProperty("summary",out var sm)?sm.GetString()??"":"";}catch{}
        var cs=new CaseSubmission{CaseNumber=caseNo,Subdomain="iis",CaseTypeId=CaseTypeId,SubmitterName=Name,SubmitterEmail=Email,SubmitterPhone=Phone??"",SaIdNumber=SaId,Description=Description,TriagedSeverity=severity,AiSummary=summary};
        Db.CaseSubmissions.Add(cs);
        var tempPwd=Guid.NewGuid().ToString()[..8];
        if(!Db.Members.Any(m=>m.Email==Email)){
            Db.Members.Add(new Member{Email=Email,FirstName=Name.Split(' ').FirstOrDefault()??"",LastName=string.Join(" ",Name.Split(' ').Skip(1)),Phone=Phone??"",MembershipNumber=CaseHelper.GenerateMembershipNumber(),PasswordHash=PasswordHelper.Hash(tempPwd)});
        }
        await Db.SaveChangesAsync();
        await _email.SendAsync(Email,"Your IIS Case Has Been Logged",$"<h2>Case Logged: {caseNo}</h2><p>Dear {Name},</p><p>Your case has been received and assigned case number <strong>{caseNo}</strong>.</p><p>Track it at <a href='https://iis.masa.org.za/track'>iis.masa.org.za/track</a> using your case number.</p><p>Login: {Email} / {tempPwd}</p><p>MASA IIS Team</p>");
        if(severity>=4){var agent=Db.AdminUsers.FirstOrDefault(u=>u.Subdomain=="iis"||u.Subdomain=="*");if(agent!=null)await _email.AlertAgentAsync(agent.Email,caseNo,summary,"iis");}
        TempData["Success"]=$"Case {caseNo} submitted. Check your email for your account credentials and case reference.";
        return RedirectToPage();
    }
}
