using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.IIS.Pages;
public class TrackModel : BasePage {
    public CaseSubmission? Case{get;set;}
    public string CaseNumber{get;set;}="";
    public bool Searched{get;set;}
    public TrackModel(MasaDbContext db):base(db){}
    public void OnGet(){}
    public IActionResult OnPost(string CaseNumber){
        this.CaseNumber=CaseNumber;Searched=true;
        Case=Db.CaseSubmissions.Include(c=>c.CaseType).FirstOrDefault(c=>c.CaseNumber==CaseNumber&&c.Subdomain=="iis");
        return Page();
    }
}
