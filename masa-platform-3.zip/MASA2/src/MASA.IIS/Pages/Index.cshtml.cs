using MASA.Shared.Data;
using MASA.Shared.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
namespace MASA.IIS.Pages;
public class IndexModel : BasePage {
    public List<CaseType> CaseTypes{get;set;}=new();
    public string HeroBannerUrl{get;set;}="";
    public IndexModel(MasaDbContext db):base(db){}
    public void OnGet(){
        CaseTypes=Db.CaseTypes.Include(c=>c.Icon).Where(c=>c.Subdomain=="iis"&&c.IsActive).OrderBy(c=>c.SortOrder).ToList();
        HeroBannerUrl=Db.MediaAssets.Where(a=>a.Subdomain=="iis"&&a.Tag=="hero_banner").OrderByDescending(a=>a.UploadedAt).FirstOrDefault()?.PublicUrl??"";
    }
}
