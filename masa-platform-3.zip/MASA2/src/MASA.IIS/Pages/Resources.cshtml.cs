using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.IIS.Pages;
public class IISResourcesModel : BasePage {
    public IISResourcesModel(MasaDbContext db):base(db){}
    public void OnGet(){}
}
