using MASA.Shared.Data;using MASA.Shared.Services;using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.IIS.Pages.Api;
[IgnoreAntiforgeryToken]
public class TutorApiModel:PageModel{
    private readonly IClaudeService _claude;
    public TutorApiModel(MasaDbContext db,IClaudeService claude){_claude=claude;}
    public async Task<IActionResult> OnPostAsync([FromBody]TutorRequest req){
        var sys="You are MASA IIS support assistant. Help users understand their rights and how to report injustices in South Africa. Be empathetic and practical.";
        var answer=await _claude.ChatAsync(sys,req.Question??"");
        return new JsonResult(new{answer});
    }
}
public record TutorRequest(string? Subject,string? Topic,string? Level,string? Question);
