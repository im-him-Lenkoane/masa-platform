using MASA.Shared.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.IIS.Pages.Api;
public class IISChatApiModel : PageModel {
    private readonly IClaudeService _claude;
    public IISChatApiModel(IClaudeService claude)=>_claude=claude;
    public async Task<IActionResult> OnPostAsync([FromBody]ChatRequest req){
        const string sys="""You are a compassionate case assistant for MASA Injustices in Society (IIS) in South Africa. Help the user describe their case and guide them through the submission form. Be empathetic and clear. If they share personal details (name, email, description), return them in a JSON field called "extracted" with keys: name, email, description. Respond in the format: {"answer":"your response","extracted":{"name":"...","email":"...","description":"..."}}""";
        var hist=req.History?.Select(h=>(h.Role,h.Content)).ToList();
        var raw=await _claude.ChatAsync(sys,req.Message,hist);
        try{var j=System.Text.Json.JsonDocument.Parse(raw);return new JsonResult(new{answer=j.RootElement.GetProperty("answer").GetString(),extracted=j.RootElement.TryGetProperty("extracted",out var ex)?(object)ex:null});}
        catch{return new JsonResult(new{answer=raw,extracted=(object?)null});}
    }
}
public record ChatMessage(string Role,string Content);
public record ChatRequest(string Message,List<ChatMessage>? History);
