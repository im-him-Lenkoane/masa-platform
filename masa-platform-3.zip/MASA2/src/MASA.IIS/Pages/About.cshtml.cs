using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.IIS.Pages;
public class IISAboutModel : BasePage {
    public string AboutText{get;set;}="";
    public IISAboutModel(MasaDbContext db):base(db){}
    public void OnGet(){AboutText=GetContent("iis","about","Content coming soon.");}
}
