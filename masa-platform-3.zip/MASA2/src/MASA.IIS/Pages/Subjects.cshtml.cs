using MASA.Shared.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace MASA.IIS.Pages;
public class IISSubjectsModel : BasePage { public IISSubjectsModel(MasaDbContext db):base(db){} public void OnGet(){} }
