namespace MASA.Shared.Helpers;
public static class CaseHelper {
    public static string GenerateCaseNumber(string subdomain)
        => $"{subdomain.ToUpper()}-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString()[..6].ToUpper()}";
    public static string GenerateMembershipNumber()
        => $"MASA-{DateTime.UtcNow:yyyy}-{Guid.NewGuid().ToString()[..8].ToUpper()}";
    public static string GenerateAccessCode()
        => $"BA-{Guid.NewGuid().ToString()[..8].ToUpper()}";
}
