using MASA.Shared.Data;
namespace MASA.Shared.Helpers;
public static class ContentHelper {
    public static string Get(MasaDbContext db, string subdomain, string page, string key, string fallback="") {
        var item = db.SiteContents.FirstOrDefault(c=>c.Subdomain==subdomain&&c.Page==page&&c.ElementKey==key);
        return item?.Value ?? fallback;
    }
}
