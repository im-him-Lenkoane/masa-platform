using Microsoft.AspNetCore.Http;
namespace MASA.Shared.Middleware;
public class AdminAuthMiddleware {
    private readonly RequestDelegate _next;
    public AdminAuthMiddleware(RequestDelegate next)=>_next=next;
    public async Task InvokeAsync(HttpContext ctx) {
        var path=ctx.Request.Path.Value?.ToLower()??"";
        // Allow login page and static files
        if(path.StartsWith("/login")||path.StartsWith("/css")||path.StartsWith("/js")||
           path.StartsWith("/images")||path.StartsWith("/fonts")||path=="/favicon.ico") {
            await _next(ctx); return;
        }
        var userId=ctx.Session.GetInt32("AdminUserId");
        if(userId==null) { ctx.Response.Redirect("/login"); return; }
        await _next(ctx);
    }
}
