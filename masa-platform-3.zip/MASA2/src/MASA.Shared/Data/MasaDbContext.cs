using Microsoft.EntityFrameworkCore;
using MASA.Shared.Models;
using MASA.Shared.Helpers;
namespace MASA.Shared.Data;

public class MasaDbContext : DbContext {
    public MasaDbContext(DbContextOptions<MasaDbContext> o) : base(o) {}

    public DbSet<Role> Roles => Set<Role>();
    public DbSet<AdminUser> AdminUsers => Set<AdminUser>();
    public DbSet<Member> Members => Set<Member>();
    public DbSet<MediaAsset> MediaAssets => Set<MediaAsset>();
    public DbSet<SiteContent> SiteContents => Set<SiteContent>();
    public DbSet<SiteMenu> SiteMenus => Set<SiteMenu>();
    public DbSet<TeamMember> TeamMembers => Set<TeamMember>();
    public DbSet<Publication> Publications => Set<Publication>();
    public DbSet<EduGrade> EduGrades => Set<EduGrade>();
    public DbSet<EduFaculty> EduFaculties => Set<EduFaculty>();
    public DbSet<EduSubject> EduSubjects => Set<EduSubject>();
    public DbSet<EduTopic> EduTopics => Set<EduTopic>();
    public DbSet<EduContent> EduContents => Set<EduContent>();
    public DbSet<EduEvent> EduEvents => Set<EduEvent>();
    public DbSet<LiveSession> LiveSessions => Set<LiveSession>();
    public DbSet<CaseType> CaseTypes => Set<CaseType>();
    public DbSet<CaseSubmission> CaseSubmissions => Set<CaseSubmission>();
    public DbSet<HealthContent> HealthContents => Set<HealthContent>();
    public DbSet<BaCourse> BaCourses => Set<BaCourse>();
    public DbSet<BaModule> BaModules => Set<BaModule>();
    public DbSet<BaLesson> BaLessons => Set<BaLesson>();
    public DbSet<BaQuiz> BaQuizzes => Set<BaQuiz>();
    public DbSet<BaEnrolment> BaEnrolments => Set<BaEnrolment>();
    public DbSet<BaAccessCode> BaAccessCodes => Set<BaAccessCode>();
    public DbSet<StemSubject> StemSubjects => Set<StemSubject>();
    public DbSet<StemTopic> StemTopics => Set<StemTopic>();
    public DbSet<Contributor> Contributors => Set<Contributor>();

    protected override void OnModelCreating(ModelBuilder b) {
        base.OnModelCreating(b);

        // Seed roles
        b.Entity<Role>().HasData(
            new Role{Id=1,Name="Super Admin",Slug="superadmin",Scope="*"},
            new Role{Id=2,Name="Site Admin",Slug="site_admin",Scope="*"},
            new Role{Id=3,Name="Edu Admin",Slug="edu_admin",Scope="edu"},
            new Role{Id=4,Name="IIS Admin",Slug="iis_admin",Scope="iis"},
            new Role{Id=5,Name="Health Admin",Slug="health_admin",Scope="health"},
            new Role{Id=6,Name="BA Admin",Slug="ba_admin",Scope="ba"},
            new Role{Id=7,Name="STEM Admin",Slug="stem_admin",Scope="stem"},
            new Role{Id=8,Name="MINM Admin",Slug="minm_admin",Scope="minm"},
            new Role{Id=9,Name="Membership Admin",Slug="membership_admin",Scope="*"},
            new Role{Id=10,Name="Members Admin",Slug="members_admin",Scope="members"}
        );

        // Seed superadmin — password: MasaAdmin@2024
        b.Entity<AdminUser>().HasData(new AdminUser{
            Id=1,Email="admin@masa.org.za",
            PasswordHash=PasswordHelper.Hash("MasaAdmin@2024"),
            FirstName="MASA",LastName="Superadmin",RoleId=1,Subdomain="*"
        });

        // Seed default menus
        b.Entity<SiteMenu>().HasData(
            new SiteMenu{Id=1,Subdomain="main",Label="Home",Url="/",SortOrder=1},
            new SiteMenu{Id=2,Subdomain="main",Label="About",Url="/about",SortOrder=2},
            new SiteMenu{Id=3,Subdomain="main",Label="Projects",Url="/projects",SortOrder=3},
            new SiteMenu{Id=4,Subdomain="main",Label="Publications",Url="/publications",SortOrder=4},
            new SiteMenu{Id=5,Subdomain="main",Label="Team",Url="/team",SortOrder=5},
            new SiteMenu{Id=6,Subdomain="main",Label="Our Story",Url="/our-story",SortOrder=6},
            new SiteMenu{Id=7,Subdomain="main",Label="Join Us",Url="/join",SortOrder=7},
            new SiteMenu{Id=8,Subdomain="edu",Label="Home",Url="/",SortOrder=1},
            new SiteMenu{Id=9,Subdomain="edu",Label="School",Url="/school",SortOrder=2},
            new SiteMenu{Id=10,Subdomain="edu",Label="Tertiary",Url="/tertiary",SortOrder=3},
            new SiteMenu{Id=11,Subdomain="edu",Label="Events",Url="/events",SortOrder=4},
            new SiteMenu{Id=12,Subdomain="edu",Label="Sessions",Url="/sessions",SortOrder=5},
            new SiteMenu{Id=13,Subdomain="edu",Label="About",Url="/about",SortOrder=6},
            new SiteMenu{Id=14,Subdomain="iis",Label="Home",Url="/",SortOrder=1},
            new SiteMenu{Id=15,Subdomain="iis",Label="Submit Case",Url="/submit",SortOrder=2},
            new SiteMenu{Id=16,Subdomain="iis",Label="Track Case",Url="/track",SortOrder=3},
            new SiteMenu{Id=17,Subdomain="iis",Label="Resources",Url="/resources",SortOrder=4},
            new SiteMenu{Id=18,Subdomain="iis",Label="About",Url="/about",SortOrder=5},
            new SiteMenu{Id=19,Subdomain="health",Label="Home",Url="/",SortOrder=1},
            new SiteMenu{Id=20,Subdomain="health",Label="SRHR",Url="/srhr",SortOrder=2},
            new SiteMenu{Id=21,Subdomain="health",Label="GBV Support",Url="/gbv",SortOrder=3},
            new SiteMenu{Id=22,Subdomain="health",Label="Diseases",Url="/diseases",SortOrder=4},
            new SiteMenu{Id=23,Subdomain="health",Label="First Aid",Url="/firstaid",SortOrder=5},
            new SiteMenu{Id=24,Subdomain="health",Label="Get Help",Url="/submit",SortOrder=6},
            new SiteMenu{Id=25,Subdomain="ba",Label="Home",Url="/",SortOrder=1},
            new SiteMenu{Id=26,Subdomain="ba",Label="Programmes",Url="/programmes",SortOrder=2},
            new SiteMenu{Id=27,Subdomain="ba",Label="My Learning",Url="/dashboard",SortOrder=3,RequiresLogin=true},
            new SiteMenu{Id=28,Subdomain="ba",Label="About",Url="/about",SortOrder=4},
            new SiteMenu{Id=29,Subdomain="stem",Label="Home",Url="/",SortOrder=1},
            new SiteMenu{Id=30,Subdomain="stem",Label="Subjects",Url="/subjects",SortOrder=2},
            new SiteMenu{Id=31,Subdomain="stem",Label="Contribute",Url="/contribute",SortOrder=3},
            new SiteMenu{Id=32,Subdomain="stem",Label="About",Url="/about",SortOrder=4},
            new SiteMenu{Id=33,Subdomain="minm",Label="Home",Url="/",SortOrder=1},
            new SiteMenu{Id=34,Subdomain="minm",Label="School Maths",Url="/school",SortOrder=2},
            new SiteMenu{Id=35,Subdomain="minm",Label="Tertiary Maths",Url="/tertiary",SortOrder=3},
            new SiteMenu{Id=36,Subdomain="minm",Label="Tutors",Url="/tutors",SortOrder=4},
            new SiteMenu{Id=37,Subdomain="minm",Label="About",Url="/about",SortOrder=5},
            new SiteMenu{Id=38,Subdomain="members",Label="Dashboard",Url="/",SortOrder=1},
            new SiteMenu{Id=39,Subdomain="members",Label="My Profile",Url="/profile",SortOrder=2},
            new SiteMenu{Id=40,Subdomain="members",Label="My Platforms",Url="/platforms",SortOrder=3}
        );

        // Seed default edu grades
        b.Entity<EduGrade>().HasData(
            new EduGrade{Id=1,Subdomain="edu",Name="Grade 10",Level="school",SortOrder=1},
            new EduGrade{Id=2,Subdomain="edu",Name="Grade 11",Level="school",SortOrder=2},
            new EduGrade{Id=3,Subdomain="edu",Name="Grade 12",Level="school",SortOrder=3},
            // MINM grades
            new EduGrade{Id=4,Subdomain="minm",Name="Grade 1",Level="school",SortOrder=1},
            new EduGrade{Id=5,Subdomain="minm",Name="Grade 2",Level="school",SortOrder=2},
            new EduGrade{Id=6,Subdomain="minm",Name="Grade 3",Level="school",SortOrder=3},
            new EduGrade{Id=7,Subdomain="minm",Name="Grade 4",Level="school",SortOrder=4},
            new EduGrade{Id=8,Subdomain="minm",Name="Grade 5",Level="school",SortOrder=5},
            new EduGrade{Id=9,Subdomain="minm",Name="Grade 6",Level="school",SortOrder=6},
            new EduGrade{Id=10,Subdomain="minm",Name="Grade 7",Level="school",SortOrder=7},
            new EduGrade{Id=11,Subdomain="minm",Name="Grade 8",Level="school",SortOrder=8},
            new EduGrade{Id=12,Subdomain="minm",Name="Grade 9",Level="school",SortOrder=9},
            new EduGrade{Id=13,Subdomain="minm",Name="Grade 10",Level="school",SortOrder=10},
            new EduGrade{Id=14,Subdomain="minm",Name="Grade 11",Level="school",SortOrder=11},
            new EduGrade{Id=15,Subdomain="minm",Name="Grade 12",Level="school",SortOrder=12}
        );

        b.Entity<EduFaculty>().HasData(
            new EduFaculty{Id=1,Subdomain="edu",Name="Health & Health Sciences",SortOrder=1},
            new EduFaculty{Id=2,Subdomain="edu",Name="Natural Sciences",SortOrder=2},
            new EduFaculty{Id=3,Subdomain="edu",Name="Engineering",SortOrder=3},
            new EduFaculty{Id=4,Subdomain="minm",Name="Pure Mathematics",SortOrder=1},
            new EduFaculty{Id=5,Subdomain="minm",Name="Applied Mathematics",SortOrder=2},
            new EduFaculty{Id=6,Subdomain="minm",Name="Statistics",SortOrder=3}
        );

        // Seed IIS case types
        b.Entity<CaseType>().HasData(
            new CaseType{Id=1,Subdomain="iis",Name="Gender-Based Violence (GBV)",SortOrder=1},
            new CaseType{Id=2,Subdomain="iis",Name="Rape Support & Reporting",SortOrder=2},
            new CaseType{Id=3,Subdomain="iis",Name="Service Delivery Failure",SortOrder=3},
            new CaseType{Id=4,Subdomain="iis",Name="Education Injustice",SortOrder=4},
            new CaseType{Id=5,Subdomain="iis",Name="Court Follow-up",SortOrder=5},
            new CaseType{Id=6,Subdomain="iis",Name="Other Social Injustice",SortOrder=6},
            new CaseType{Id=7,Subdomain="health",Name="SRHR Concern",SortOrder=1},
            new CaseType{Id=8,Subdomain="health",Name="GBV Support",SortOrder=2},
            new CaseType{Id=9,Subdomain="health",Name="Chronic Disease Support",SortOrder=3},
            new CaseType{Id=10,Subdomain="health",Name="Rare Disease Enquiry",SortOrder=4}
        );

        // Seed team member
        b.Entity<TeamMember>().HasData(new TeamMember{
            Id=1,Subdomain="main",Name="Morgan Itumeleng Lenkoane",
            Role="Founder & Co-Establisher",
            Bio="Driving MASA's mission through education, technology, and social action across South Africa.",
            SortOrder=1
        });

        // Seed default site content
        b.Entity<SiteContent>().HasData(
            new SiteContent{Id=1,Subdomain="main",Page="home",ElementKey="hero_title",Value="Action.\nEducation.\nJustice."},
            new SiteContent{Id=2,Subdomain="main",Page="home",ElementKey="hero_subtitle",Value="A South African non-profit advancing communities through accessible education, advocacy, health support, and skills development."},
            new SiteContent{Id=3,Subdomain="main",Page="home",ElementKey="mission_title",Value="Built on the belief that every South African deserves a fair opportunity."},
            new SiteContent{Id=4,Subdomain="main",Page="about",ElementKey="about_body",Value="The Messelaar Agency for Social Action NPC is a South African non-profit dedicated to improving the lives of communities through accessible education, technology-enabled advocacy, and holistic health and social support systems."},
            new SiteContent{Id=5,Subdomain="main",Page="about",ElementKey="mission_statement",Value="To bridge systemic gaps in education, justice, health, and opportunity for every South African — through action, technology, and community."},
            new SiteContent{Id=6,Subdomain="main",Page="about",ElementKey="vision_statement",Value="A South Africa where access to quality education, social justice, and healthcare is a right exercised by all — not a privilege of the few."},
            new SiteContent{Id=7,Subdomain="edu",Page="home",ElementKey="hero_title",Value="Knowledge for every South African student."},
            new SiteContent{Id=8,Subdomain="edu",Page="home",ElementKey="hero_subtitle",Value="From Grade 10 to university — access subject content, AI tutoring, and live sessions."},
            new SiteContent{Id=9,Subdomain="iis",Page="home",ElementKey="hero_title",Value="Your injustice is not invisible."},
            new SiteContent{Id=10,Subdomain="iis",Page="home",ElementKey="hero_subtitle",Value="We listen, we document, we act. Report GBV, service delivery failures, and social injustices confidentially."},
            new SiteContent{Id=11,Subdomain="health",Page="home",ElementKey="hero_title",Value="Your health. Our commitment."},
            new SiteContent{Id=12,Subdomain="health",Page="home",ElementKey="hero_subtitle",Value="SRHR, GBV support, chronic and rare disease assistance — free, confidential, and community-driven."},
            new SiteContent{Id=13,Subdomain="health",Page="home",ElementKey="emergency_text",Value="In an emergency call 10177 or 112"},
            new SiteContent{Id=14,Subdomain="ba",Page="home",ElementKey="hero_title",Value="Build Skills. Build Futures."},
            new SiteContent{Id=15,Subdomain="ba",Page="home",ElementKey="hero_subtitle",Value="The Builders Academy provides hands-on training in computer science, physical skills, and trades for South African youth."},
            new SiteContent{Id=16,Subdomain="stem",Page="home",ElementKey="hero_title",Value="Making South Africa STEM Literate."},
            new SiteContent{Id=17,Subdomain="stem",Page="home",ElementKey="hero_subtitle",Value="Science, technology, engineering, and mathematics — taught outside the classroom for every young South African."},
            new SiteContent{Id=18,Subdomain="minm",Page="home",ElementKey="hero_title",Value="Maths for Every Mind."},
            new SiteContent{Id=19,Subdomain="minm",Page="home",ElementKey="hero_subtitle",Value="From Grade 1 to university — Morgan Itumeleng Lenkoane teaches all levels and types of mathematics."},
            new SiteContent{Id=20,Subdomain="minm",Page="home",ElementKey="morgan_quote",Value="Mathematics is not a subject — it is a language. Once you speak it, the world makes sense."},
            new SiteContent{Id=21,Subdomain="members",Page="home",ElementKey="welcome_text",Value="Welcome to your MASA Members Portal."}
        );

        b.Entity<AdminUser>().HasIndex(u=>u.Email).IsUnique();
        b.Entity<Member>().HasIndex(m=>m.Email).IsUnique();
        b.Entity<Member>().HasIndex(m=>m.MembershipNumber).IsUnique();
        b.Entity<CaseSubmission>().HasIndex(c=>c.CaseNumber).IsUnique();
        b.Entity<SiteContent>().HasIndex(s=>new{s.Subdomain,s.Page,s.ElementKey}).IsUnique();
    }
}
