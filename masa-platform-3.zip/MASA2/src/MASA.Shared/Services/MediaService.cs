using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Configuration;
using MASA.Shared.Data;
using MASA.Shared.Models;
namespace MASA.Shared.Services;
public class MediaService : IMediaService {
    private readonly IAmazonS3 _s3;
    private readonly MasaDbContext _db;
    private readonly string _bucket, _cdn;
    private static readonly string[] _allowed = {
        "image/jpeg","image/png","image/gif","image/webp","image/svg+xml",
        "application/pdf","video/mp4","video/webm",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    };
    public MediaService(IAmazonS3 s3, IConfiguration cfg, MasaDbContext db) {
        _s3=s3; _db=db;
        _bucket=cfg["AWS:BucketName"]??"masa-media";
        _cdn=cfg["AWS:CdnBase"]??"https://masa-media.s3.af-south-1.amazonaws.com";
    }
    public bool IsAllowedType(string mime) => _allowed.Contains(mime.ToLower());
    public async Task<(string key,string url)> UploadAsync(Stream s, string fn, string sub, string cat, string mime) {
        var ext=Path.GetExtension(fn);
        var key=$"masa/{sub}/{cat}/{Guid.NewGuid()}{ext}";
        await _s3.PutObjectAsync(new PutObjectRequest{
            BucketName=_bucket,Key=key,InputStream=s,ContentType=mime,CannedACL=S3CannedACL.PublicRead
        });
        var url=GetPublicUrl(key);
        _db.MediaAssets.Add(new MediaAsset{FileName=fn,S3Key=key,PublicUrl=url,MimeType=mime,Subdomain=sub,Category=cat,FileSizeBytes=s.Length});
        await _db.SaveChangesAsync();
        return (key,url);
    }
    public async Task<bool> DeleteAsync(string key) {
        await _s3.DeleteObjectAsync(_bucket,key);
        var a=_db.MediaAssets.FirstOrDefault(m=>m.S3Key==key);
        if(a!=null){_db.MediaAssets.Remove(a);await _db.SaveChangesAsync();}
        return true;
    }
    public string GetPublicUrl(string key) => $"{_cdn}/{key}";
}
