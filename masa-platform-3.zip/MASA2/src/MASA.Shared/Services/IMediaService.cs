namespace MASA.Shared.Services;
public interface IMediaService {
    Task<(string key, string url)> UploadAsync(Stream s, string fn, string subdomain, string category, string mime);
    Task<bool> DeleteAsync(string key);
    string GetPublicUrl(string key);
    bool IsAllowedType(string mime);
}
