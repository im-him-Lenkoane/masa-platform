using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class StemTopic {
    public int Id { get; set; }
    public int SubjectId { get; set; }
    public StemSubject? Subject { get; set; }
    [Required,MaxLength(200)] public string Title { get; set; }="";
    public string Body { get; set; }="";
    public string VideoUrl { get; set; }="";
    public string DidYouKnow { get; set; }="";
    public int? ImageAssetId { get; set; }
    public MediaAsset? Image { get; set; }
    public bool IsPublished { get; set; }=false;
    public int SortOrder { get; set; }=0;
}
