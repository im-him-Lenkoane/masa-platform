using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class EduFaculty {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="edu";
    [Required,MaxLength(120)] public string Name { get; set; }="";
    public string Description { get; set; }="";
    public int? IconAssetId { get; set; }
    public MediaAsset? Icon { get; set; }
    public int SortOrder { get; set; }=0;
    public bool IsActive { get; set; }=true;
    public ICollection<EduSubject> Subjects { get; set; }=new List<EduSubject>();
}
