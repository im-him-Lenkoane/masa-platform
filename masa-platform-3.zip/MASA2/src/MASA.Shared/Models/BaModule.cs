using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class BaModule {
    public int Id { get; set; }
    public int CourseId { get; set; }
    public BaCourse? Course { get; set; }
    [Required,MaxLength(200)] public string Title { get; set; }="";
    public int SortOrder { get; set; }=0;
    public ICollection<BaLesson> Lessons { get; set; }=new List<BaLesson>();
}
