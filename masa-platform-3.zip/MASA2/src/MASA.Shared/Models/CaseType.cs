using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class CaseType {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="iis";
    [Required,MaxLength(100)] public string Name { get; set; }="";
    public string Description { get; set; }="";
    public int? IconAssetId { get; set; }
    public MediaAsset? Icon { get; set; }
    public bool IsActive { get; set; }=true;
    public int SortOrder { get; set; }=0;
}
