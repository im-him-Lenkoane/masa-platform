using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class Role {
    public int Id { get; set; }
    [Required,MaxLength(60)] public string Name { get; set; }="";
    [MaxLength(40)] public string Slug { get; set; }="";
    [MaxLength(20)] public string Scope { get; set; }="*";
    public ICollection<AdminUser> AdminUsers { get; set; }=new List<AdminUser>();
}
