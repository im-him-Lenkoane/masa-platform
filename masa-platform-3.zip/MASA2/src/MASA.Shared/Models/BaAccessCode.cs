using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class BaAccessCode {
    public int Id { get; set; }
    [Required,MaxLength(20)] public string Code { get; set; }="";
    public int? CourseId { get; set; }
    public bool IsUsed { get; set; }=false;
    public int? UsedByMemberId { get; set; }
    public DateTime CreatedAt { get; set; }=DateTime.UtcNow;
    public DateTime? UsedAt { get; set; }
    public DateTime? ExpiresAt { get; set; }
}
