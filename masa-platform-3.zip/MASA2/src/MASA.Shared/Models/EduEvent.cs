using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class EduEvent {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="edu";
    public int? SubjectId { get; set; }
    [Required,MaxLength(200)] public string Title { get; set; }="";
    public string Description { get; set; }="";
    public DateTime EventDate { get; set; }=DateTime.UtcNow;
    [MaxLength(200)] public string Location { get; set; }="";
    public string StreamUrl { get; set; }="";
    public bool IsPublished { get; set; }=false;
}
