using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class LiveSession {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="edu";
    [Required,MaxLength(200)] public string Title { get; set; }="";
    public string Description { get; set; }="";
    public DateTime SessionDate { get; set; }=DateTime.UtcNow;
    [MaxLength(20)] public string StreamType { get; set; }="youtube";
    public string StreamUrl { get; set; }="";
    public bool IsLive { get; set; }=false;
    public bool IsPublished { get; set; }=false;
    public int? SubjectId { get; set; }
}
