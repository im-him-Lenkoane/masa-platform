using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class SiteMenu {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="";
    [MaxLength(100)] public string Label { get; set; }="";
    [MaxLength(200)] public string Url { get; set; }="";
    public int SortOrder { get; set; }=0;
    public bool IsActive { get; set; }=true;
    public bool RequiresLogin { get; set; }=false;
}
