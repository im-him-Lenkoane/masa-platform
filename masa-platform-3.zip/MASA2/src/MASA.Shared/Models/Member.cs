using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class Member {
    public int Id { get; set; }
    [Required,MaxLength(150)] public string Email { get; set; }="";
    [MaxLength(80)] public string FirstName { get; set; }="";
    [MaxLength(80)] public string LastName { get; set; }="";
    [MaxLength(20)] public string Phone { get; set; }="";
    [MaxLength(13)] public string? SaIdNumber { get; set; }
    public string MembershipNumber { get; set; }="";
    public bool IsActive { get; set; }=true;
    public DateTime JoinedAt { get; set; }=DateTime.UtcNow;
    public string Notes { get; set; }="";
    public string PasswordHash { get; set; }="";
    public bool HasEduAccess { get; set; }=false;
    public bool HasBaAccess { get; set; }=false;
    public bool HasMinmAccess { get; set; }=false;
}
