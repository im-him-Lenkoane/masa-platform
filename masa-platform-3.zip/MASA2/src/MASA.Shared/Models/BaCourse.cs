using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class BaCourse {
    public int Id { get; set; }
    [Required,MaxLength(200)] public string Title { get; set; }="";
    [MaxLength(100)] public string Category { get; set; }="";
    public string Description { get; set; }="";
    public int? BannerAssetId { get; set; }
    public MediaAsset? Banner { get; set; }
    public int DurationWeeks { get; set; }=0;
    public bool IsPublished { get; set; }=false;
    public DateTime CreatedAt { get; set; }=DateTime.UtcNow;
    public ICollection<BaModule> Modules { get; set; }=new List<BaModule>();
    public ICollection<BaEnrolment> Enrolments { get; set; }=new List<BaEnrolment>();
}
