using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class TeamMember {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="main";
    [Required,MaxLength(150)] public string Name { get; set; }="";
    [MaxLength(150)] public string Role { get; set; }="";
    public string Bio { get; set; }="";
    public int? PhotoAssetId { get; set; }
    public MediaAsset? Photo { get; set; }
    public int SortOrder { get; set; }=0;
    public bool IsActive { get; set; }=true;
}
