using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class MediaAsset {
    public int Id { get; set; }
    [Required,MaxLength(500)] public string FileName { get; set; }="";
    [Required,MaxLength(1000)] public string S3Key { get; set; }="";
    [MaxLength(2000)] public string PublicUrl { get; set; }="";
    [MaxLength(100)] public string MimeType { get; set; }="";
    public long FileSizeBytes { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="global";
    [MaxLength(40)] public string Category { get; set; }="image";
    [MaxLength(200)] public string AltText { get; set; }="";
    [MaxLength(200)] public string Tag { get; set; }="";
    public DateTime UploadedAt { get; set; }=DateTime.UtcNow;
    public int? UploadedByUserId { get; set; }
}
