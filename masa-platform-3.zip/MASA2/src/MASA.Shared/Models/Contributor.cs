using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class Contributor {
    public int Id { get; set; }
    [Required,MaxLength(150)] public string Name { get; set; }="";
    [Required,MaxLength(150)] public string Email { get; set; }="";
    public string Expertise { get; set; }="";
    public string SampleUrl { get; set; }="";
    public string Motivation { get; set; }="";
    [MaxLength(30)] public string Status { get; set; }="pending";
    public DateTime AppliedAt { get; set; }=DateTime.UtcNow;
}
