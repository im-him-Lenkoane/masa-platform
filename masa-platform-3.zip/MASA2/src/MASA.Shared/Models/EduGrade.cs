using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class EduGrade {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="edu";
    [Required,MaxLength(50)] public string Name { get; set; }="";
    [MaxLength(20)] public string Level { get; set; }="school";
    public int SortOrder { get; set; }=0;
    public bool IsActive { get; set; }=true;
    public ICollection<EduSubject> Subjects { get; set; }=new List<EduSubject>();
}
