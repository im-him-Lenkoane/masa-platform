using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class HealthContent {
    public int Id { get; set; }
    [MaxLength(30)] public string Category { get; set; }="";
    [Required,MaxLength(200)] public string Title { get; set; }="";
    public string Body { get; set; }="";
    public string VideoUrl { get; set; }="";
    public int? BannerAssetId { get; set; }
    public MediaAsset? Banner { get; set; }
    public bool RequiresAgeGate { get; set; }=false;
    public bool IsPublished { get; set; }=false;
    public int SortOrder { get; set; }=0;
}
