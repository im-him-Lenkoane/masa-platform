using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class AdminUser {
    public int Id { get; set; }
    [Required,MaxLength(150)] public string Email { get; set; }="";
    [Required] public string PasswordHash { get; set; }="";
    [MaxLength(80)] public string FirstName { get; set; }="";
    [MaxLength(80)] public string LastName { get; set; }="";
    public int RoleId { get; set; }
    public Role? Role { get; set; }
    public bool IsActive { get; set; }=true;
    public DateTime CreatedAt { get; set; }=DateTime.UtcNow;
    public DateTime? LastLoginAt { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="*";
}
