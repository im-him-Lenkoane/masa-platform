using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class Publication {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="main";
    [Required,MaxLength(300)] public string Title { get; set; }="";
    public string Abstract { get; set; }="";
    public int? DocumentAssetId { get; set; }
    public MediaAsset? Document { get; set; }
    public string ExternalUrl { get; set; }="";
    public DateTime PublishedAt { get; set; }=DateTime.UtcNow;
    public bool IsPublished { get; set; }=false;
}
