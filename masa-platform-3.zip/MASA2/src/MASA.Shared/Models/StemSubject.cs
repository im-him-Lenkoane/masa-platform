using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class StemSubject {
    public int Id { get; set; }
    [Required,MaxLength(150)] public string Name { get; set; }="";
    public string Description { get; set; }="";
    public int? IconAssetId { get; set; }
    public MediaAsset? Icon { get; set; }
    public int? BannerAssetId { get; set; }
    public MediaAsset? Banner { get; set; }
    public bool IsPublished { get; set; }=false;
    public int SortOrder { get; set; }=0;
    public ICollection<StemTopic> Topics { get; set; }=new List<StemTopic>();
}
