using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class BaQuiz {
    public int Id { get; set; }
    public int LessonId { get; set; }
    [Required,MaxLength(500)] public string Question { get; set; }="";
    [MaxLength(200)] public string OptionA { get; set; }="";
    [MaxLength(200)] public string OptionB { get; set; }="";
    [MaxLength(200)] public string OptionC { get; set; }="";
    [MaxLength(200)] public string OptionD { get; set; }="";
    [MaxLength(1)] public string CorrectOption { get; set; }="A";
    public int SortOrder { get; set; }=0;
}
