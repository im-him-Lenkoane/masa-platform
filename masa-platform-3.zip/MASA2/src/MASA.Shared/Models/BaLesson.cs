using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class BaLesson {
    public int Id { get; set; }
    public int ModuleId { get; set; }
    public BaModule? Module { get; set; }
    [Required,MaxLength(200)] public string Title { get; set; }="";
    [MaxLength(40)] public string LessonType { get; set; }="video";
    public string Content { get; set; }="";
    public int? MediaAssetId { get; set; }
    public MediaAsset? Asset { get; set; }
    public string VideoUrl { get; set; }="";
    public int DurationMinutes { get; set; }=0;
    public int SortOrder { get; set; }=0;
}
