using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class SiteContent {
    public int Id { get; set; }
    [Required,MaxLength(20)] public string Subdomain { get; set; }="";
    [Required,MaxLength(100)] public string Page { get; set; }="";
    [Required,MaxLength(200)] public string ElementKey { get; set; }="";
    public string Value { get; set; }="";
    public int? MediaAssetId { get; set; }
    public MediaAsset? MediaAsset { get; set; }
    public DateTime UpdatedAt { get; set; }=DateTime.UtcNow;
}
