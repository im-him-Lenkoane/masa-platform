using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class EduSubject {
    public int Id { get; set; }
    [MaxLength(20)] public string Subdomain { get; set; }="edu";
    [Required,MaxLength(150)] public string Name { get; set; }="";
    [MaxLength(20)] public string Level { get; set; }="school";
    public int? GradeId { get; set; }
    public EduGrade? Grade { get; set; }
    public int? FacultyId { get; set; }
    public EduFaculty? Faculty { get; set; }
    public string Description { get; set; }="";
    public int? BannerAssetId { get; set; }
    public MediaAsset? Banner { get; set; }
    public int? TextbookAssetId { get; set; }
    public int? NotesAssetId { get; set; }
    public bool IsPublished { get; set; }=false;
    public int SortOrder { get; set; }=0;
    public ICollection<EduTopic> Topics { get; set; }=new List<EduTopic>();
}
