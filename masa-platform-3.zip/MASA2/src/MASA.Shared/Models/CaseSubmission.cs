using System.ComponentModel.DataAnnotations;
namespace MASA.Shared.Models;
public class CaseSubmission {
    public int Id { get; set; }
    [Required,MaxLength(30)] public string CaseNumber { get; set; }="";
    [MaxLength(20)] public string Subdomain { get; set; }="";
    public int? CaseTypeId { get; set; }
    public CaseType? CaseType { get; set; }
    [Required,MaxLength(150)] public string SubmitterName { get; set; }="";
    [Required,MaxLength(150)] public string SubmitterEmail { get; set; }="";
    [MaxLength(20)] public string SubmitterPhone { get; set; }="";
    [MaxLength(13)] public string? SaIdNumber { get; set; }
    [Required] public string Description { get; set; }="";
    [MaxLength(30)] public string Status { get; set; }="open";
    public int TriagedSeverity { get; set; }=0;
    public string AiSummary { get; set; }="";
    public int? AssignedAgentId { get; set; }
    public string AgentNotes { get; set; }="";
    public DateTime SubmittedAt { get; set; }=DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; }=DateTime.UtcNow;
    public int? CreatedMemberId { get; set; }
}
