#!/bin/bash
# MASA Platform — Fresh EC2 Ubuntu 22.04 Setup
# Run once as ubuntu user after cloning the repo
set -e

echo "=== 1. Update system ==="
sudo apt update && sudo apt upgrade -y

echo "=== 2. Install .NET 8 ==="
sudo apt install -y dotnet-sdk-8.0

echo "=== 3. Install Nginx ==="
sudo apt install -y nginx
sudo systemctl enable nginx && sudo systemctl start nginx

echo "=== 4. Install PostgreSQL ==="
sudo apt install -y postgresql postgresql-contrib
sudo systemctl enable postgresql && sudo systemctl start postgresql

echo "=== 5. Install unzip ==="
sudo apt install -y unzip

echo "=== 6. Create web directories ==="
sudo mkdir -p /var/www/masa/{main,admin,edu,iis,health,ba,stem,minm,members}
sudo chown -R www-data:www-data /var/www/masa

echo "=== 7. Setup PostgreSQL ==="
echo "Run these commands manually:"
echo "  sudo -u postgres psql"
echo "  CREATE USER masa_user WITH PASSWORD 'your_password';"
echo "  CREATE DATABASE masadb OWNER masa_user;"
echo "  GRANT ALL PRIVILEGES ON DATABASE masadb TO masa_user;"
echo "  \q"

echo "=== 8. Configure Nginx ==="
sudo cp nginx/masa.conf /etc/nginx/sites-available/masa
sudo ln -sf /etc/nginx/sites-available/masa /etc/nginx/sites-enabled/masa
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

echo "=== 9. Install systemd services ==="
sudo cp scripts/systemd/*.service /etc/systemd/system/
sudo systemctl daemon-reload
for s in main admin edu iis health ba stem minm members; do
  sudo systemctl enable masa-$s
done

echo "=== 10. Update appsettings.json ==="
echo "Edit each src/MASA.*/appsettings.json with your real DB password, AWS keys, Claude API key, and email settings."
echo ""
echo "=== Setup complete. Run: bash scripts/deploy.sh ==="
