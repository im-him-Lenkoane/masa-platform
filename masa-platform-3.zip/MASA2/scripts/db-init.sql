-- MASA Platform PostgreSQL initialisation
-- Run once on a fresh EC2 instance
-- sudo -u postgres psql -f scripts/db-init.sql

CREATE USER masa_user WITH PASSWORD 'CHANGE_ME_IN_PRODUCTION';
CREATE DATABASE masadb OWNER masa_user;
GRANT ALL PRIVILEGES ON DATABASE masadb TO masa_user;

-- The .NET app will auto-create all tables via EnsureCreated() on first startup.
