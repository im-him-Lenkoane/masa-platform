#!/bin/bash
# MASA Platform — EC2 Deploy Script
# Run from project root: bash scripts/deploy.sh
set -e
APPS=("Main" "Admin" "Edu" "IIS" "Health" "BA" "STEM" "MINM" "Members")
SLUGS=("main" "admin" "edu" "iis" "health" "ba" "stem" "minm" "members")

echo "=== Building MASA Platform ==="
dotnet restore MASA.sln --nologo -q

for i in "${!APPS[@]}"; do
  APP="${APPS[$i]}"
  SLUG="${SLUGS[$i]}"
  echo "  Publishing MASA.$APP..."
  dotnet publish src/MASA.$APP/MASA.$APP.csproj \
    -c Release -o /var/www/masa/$SLUG \
    --nologo -q
done

echo "=== Restarting services ==="
for SLUG in "${SLUGS[@]}"; do
  sudo systemctl restart masa-$SLUG || echo "  Warning: masa-$SLUG restart failed"
done

echo "=== Done. All MASA services restarted. ==="
sudo systemctl status masa-main --no-pager -l | tail -5
