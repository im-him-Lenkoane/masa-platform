# MASA Platform

**Messelaar Agency for Social Action NPC** — Full-stack multi-subdomain platform.

## Stack
- **Framework**: ASP.NET Core 8 + Razor Pages (C#)
- **Database**: PostgreSQL (self-hosted on EC2)
- **Storage**: AWS S3 (`masa-media` bucket)
- **Compute**: AWS EC2 + Nginx
- **DNS/CDN**: Cloudflare
- **AI**: Anthropic Claude API
- **CI/CD**: GitHub Actions

## Sites

| Project        | Subdomain              | Port |
|----------------|------------------------|------|
| MASA.Main      | masa.org.za            | 5000 |
| MASA.Admin     | admin.masa.org.za      | 5001 |
| MASA.Edu       | edu.masa.org.za        | 5002 |
| MASA.IIS       | iis.masa.org.za        | 5003 |
| MASA.Health    | health.masa.org.za     | 5004 |
| MASA.BA        | ba.masa.org.za         | 5005 |
| MASA.STEM      | stem.masa.org.za       | 5006 |
| MASA.MINM      | minm.masa.org.za       | 5007 |
| MASA.Members   | members.masa.org.za    | 5008 |

## Quick Start

```bash
# 1. Clone onto EC2
git clone https://github.com/YOUR_USERNAME/masa-platform.git
cd masa-platform

# 2. Run EC2 setup (once)
bash scripts/ec2-setup.sh

# 3. Setup PostgreSQL database
sudo -u postgres psql
# CREATE USER masa_user WITH PASSWORD 'your_password';
# CREATE DATABASE masadb OWNER masa_user;
# GRANT ALL PRIVILEGES ON DATABASE masadb TO masa_user;

# 4. Update all appsettings.json files
find . -name "appsettings.json" -exec sed -i "s/CHANGE_ME/your_db_password/g" {} ;

# 5. Deploy
bash scripts/deploy.sh
```

## Default Admin Login
- URL: https://admin.masa.org.za
- Email: admin@masa.org.za
- Password: MasaAdmin@2024
- **CHANGE THIS IMMEDIATELY after first login**

## GitHub Secrets for CI/CD
- `EC2_HOST` — EC2 public IP
- `EC2_USER` — usually `ubuntu`
- `EC2_SSH_KEY` — private SSH key

## appsettings.json Keys Required
- `ConnectionStrings:DefaultConnection`
- `AWS:Region`, `AWS:BucketName`, `AWS:CdnBase`
- `Claude:ApiKey`
- `Email:SmtpHost`, `Email:SmtpPort`, `Email:Username`, `Email:Password`
